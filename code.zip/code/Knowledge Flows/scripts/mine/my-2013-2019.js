const config = {
    width: 1000,
    height: 800,
    radius: 200,
    scale: 15,
    linkOffset: 15,
    textSize: 20
  };

const scaleFactor = 1.5;
  
  const nodes = [{ id: 0, name: "CDDG", papers: 1567 },
    { id: 1, name: "BDNI", papers: 2004 },{ id: 2, name: "MIRG", papers: 2130 },
    { id: 3, name: "CVHI", papers: 2584 },{ id: 4, name: "MIRC", papers: 2266 },
      { id: 5, name: "SNCP", papers: 828 },{ id: 6, name: "MISG", papers: 2499 }];
   
  const rawLinks = [
      {
        "source": 5,
        "target": 5,
        "cites": 232
      },
      {
        "source": 4,
        "target": 4,
        "cites": 946
      },
      {
        "source": 3,
        "target": 2,
        "cites": 115
      },
      {
        "source": 2,
        "target": 2,
        "cites": 947
      },
      {
        "source": 3,
        "target": 3,
        "cites": 1273
      },
      {
        "source": 2,
        "target": 1,
        "cites": 69
      },
      {
        "source": 1,
        "target": 1,
        "cites": 642
      },
      {
        "source": 6,
        "target": 6,
        "cites": 1223
      },
      {
        "source": 6,
        "target": 0,
        "cites": 220
      },
      {
        "source": 0,
        "target": 0,
        "cites": 554
      },
      {
        "source": 3,
        "target": 1,
        "cites": 26
      },
      {
        "source": 1,
        "target": 6,
        "cites": 61
      },
      {
        "source": 2,
        "target": 4,
        "cites": 53
      },
      {
        "source": 4,
        "target": 2,
        "cites": 69
      },
      {
        "source": 1,
        "target": 2,
        "cites": 55
      },
      {
        "source": 6,
        "target": 3,
        "cites": 256
      },
      {
        "source": 2,
        "target": 3,
        "cites": 145
      },
      {
        "source": 6,
        "target": 2,
        "cites": 248
      },
      {
        "source": 0,
        "target": 3,
        "cites": 34
      },
      {
        "source": 0,
        "target": 6,
        "cites": 204
      },
      {
        "source": 2,
        "target": 6,
        "cites": 208
      },
      {
        "source": 4,
        "target": 6,
        "cites": 73
      },
      {
        "source": 3,
        "target": 6,
        "cites": 184
      },
      {
        "source": 6,
        "target": 1,
        "cites": 86
      },
      {
        "source": 2,
        "target": 5,
        "cites": 16
      },
      {
        "source": 5,
        "target": 6,
        "cites": 26
      },
      {
        "source": 4,
        "target": 1,
        "cites": 48
      },
      {
        "source": 0,
        "target": 1,
        "cites": 12
      },
      {
        "source": 6,
        "target": 4,
        "cites": 96
      },
      {
        "source": 1,
        "target": 4,
        "cites": 57
      },
      {
        "source": 2,
        "target": 0,
        "cites": 33
      },
      {
        "source": 0,
        "target": 5,
        "cites": 13
      },
      {
        "source": 5,
        "target": 4,
        "cites": 4
      },
      {
        "source": 1,
        "target": 0,
        "cites": 23
      },
      {
        "source": 5,
        "target": 3,
        "cites": 16
      },
      {
        "source": 4,
        "target": 0,
        "cites": 21
      },
      {
        "source": 1,
        "target": 3,
        "cites": 24
      },
      {
        "source": 1,
        "target": 5,
        "cites": 3
      },
      {
        "source": 3,
        "target": 0,
        "cites": 29
      },
      {
        "source": 0,
        "target": 2,
        "cites": 32
      },
      {
        "source": 3,
        "target": 4,
        "cites": 48
      },
      {
        "source": 6,
        "target": 5,
        "cites": 31
      },
      {
        "source": 4,
        "target": 3,
        "cites": 61
      },
      {
        "source": 5,
        "target": 2,
        "cites": 24
      },
      {
        "source": 3,
        "target": 5,
        "cites": 10
      },
      {
        "source": 0,
        "target": 4,
        "cites": 18
      },
      {
        "source": 5,
        "target": 0,
        "cites": 6
      },
      {
        "source": 4,
        "target": 5,
        "cites": 8
      },
      {
        "source": 5,
        "target": 1,
        "cites": 1
      }
    ];
  
  const svg = d3.select("body")
          .append("svg")
          .attr("width", config.width)
          .attr("height", config.height);
  
  svg.append("text")
             .text("2013 - 2019")
             .attr("x", config.width / 2)
             .attr("y", 50)
             .attr("text-anchor", "middle")
             .attr("font-size", "40px")
             .attr("fill", "black")
             .attr("font-weight", "bold")
             .attr('opacity',0);
  
  svg.append("defs")
             .append("marker")
             .attr("id", "arrow")
             .attr("viewBox", "0 -5 10 10")
             .attr("refX", 8)
             .attr("markerWidth", 6)
             .attr("markerHeight", 6)
             .attr("orient", "auto")
             .append("path")
             .attr("d", "M0,-3L10,0L0,3")
             .attr("fill", "#666");
  
  const nodePositions = calculatePentagonPositions(config.width / 2, config.height / 2, config.radius * scaleFactor);
  const totalPapers = d3.sum(nodes, d => d.papers);
  const totalCitations = d3.sum(rawLinks, d => d.cites);
  const links = rawLinks.map(link => {
        const source = nodes[link.source];
        const target = nodes[link.target];
        const expected = (source.papers / totalPapers) * (target.papers / totalPapers) * totalCitations;
        return {
                  source: link.source,
                  target: link.target,
                  weight: link.cites / expected,
                  actual: link.cites
              };
          });
  
  const minWeight = d3.min(links, d => d.weight);
  const maxWeight = d3.max(links, d => d.weight);
  
  const strokeScale = d3.scaleLinear()
             .domain([minWeight, maxWeight])
             .range([0.5, 35]);
  
  const linkGroup = svg.append("g")
             .selectAll("path")
             .data(links.filter(d => d.weight))
             .join("path")
             .attr("class", "link")
             .attr("fill", "none")
             .attr("stroke", "#666")
             .attr("stroke-width", d => strokeScale(d.weight))
             .attr("marker-end", d => (d.source === d.target ? null : "url(#arrow)"))
             .attr("d", d => generateParallelPath(d))
             .attr("stroke-dasharray", d => d.weight.toFixed(1) < "0.3" ? "5,5" : null);
  
  const nodeColors = ["#4d78a6", "#f08d2c", "#df5658", "#75b6b1", "#58a04e",'#ebc748', '#ae79a0'];
  
  const nodeGroup = svg.append("g")
             .selectAll("circle")
             .data(nodes)
             .join("circle")
             .attr("r", d => Math.log10(d.papers) * config.scale)
             .attr("fill", (d, i) => nodeColors[i])
             .attr("stroke", "#333")
             .attr("stroke-width", 2)
             .attr("cx", (d, i) => nodePositions[i].x)
             .attr("cy", (d, i) => nodePositions[i].y);
  
  svg.append("g")
             .selectAll("text")
             .data(nodes)
             .join("text")
             .text(d => d.name)
             .attr("text-anchor", "middle")
             .attr("dominant-baseline", "central")
             .attr("fill", "black")
             .attr("x", (d, i) => nodePositions[i].x)
             .attr("y", (d, i) => nodePositions[i].y)
             .attr("font-size", "32px");
  
  svg.append("g")
             .selectAll("text")
             .data(links.filter(d => d.weight >= 0.4))
             .join("text")
             .text(d => d.weight.toFixed(1))
             .attr("font-size", `${config.textSize}px`)
             .attr("fill", "#333")
             .attr("x", d => getLabelPosition(d).x - 20)
             .attr("y", d => getLabelPosition(d).y + 20);
  
  function getLinkEndpoints(d) {
              if (d.source === d.target) {
                  const sourcePos = nodePositions[d.source];
                  const sourceRadius = Math.log10(nodes[d.source].papers) * config.scale;
                  let startX, startY, endX, endY;
                  switch (d.source) {
                      case 0:
                          startX = sourcePos.x - sourceRadius;
                          startY = sourcePos.y;
                          endX = sourcePos.x + sourceRadius;
                          endY = sourcePos.y;
                          break;
                      case 1:
                          startX = sourcePos.x;
                          startY = sourcePos.y - sourceRadius;
                          endX = sourcePos.x;
                          endY = sourcePos.y + sourceRadius;
                          break;
                      case 2:
                          const mlAngle = Math.PI / 6;
                          startX = sourcePos.x + sourceRadius * Math.cos(mlAngle);
                          startY = sourcePos.y + sourceRadius * Math.sin(mlAngle);
                          endX = sourcePos.x + sourceRadius * Math.cos(mlAngle + Math.PI);
                          endY = sourcePos.y + sourceRadius * Math.sin(mlAngle + Math.PI);
                          break;
                      case 3:
                          const nlpAngle = Math.PI / 3;
                          startX = sourcePos.x + sourceRadius * Math.cos(nlpAngle);
                          startY = sourcePos.y + sourceRadius * Math.sin(nlpAngle);
                          endX = sourcePos.x + sourceRadius * Math.cos(nlpAngle + Math.PI);
                          endY = sourcePos.y + sourceRadius * Math.sin(nlpAngle + Math.PI);
                          break;
                      case 4:
                          startX = sourcePos.x;
                          startY = sourcePos.y + sourceRadius;
                          endX = sourcePos.x;
                          endY = sourcePos.y - sourceRadius;
                          break;
                      case 5: // 斜向 120°
                        const angle5 = (2 * Math.PI) / 3;
                        startX = sourcePos.x + sourceRadius * Math.cos(angle5);
                        startY = sourcePos.y + sourceRadius * Math.sin(angle5);
                        endX = sourcePos.x + sourceRadius * Math.cos(angle5 + Math.PI);
                        endY = sourcePos.y + sourceRadius * Math.sin(angle5 + Math.PI);
                        break;
                      case 6: // 斜向 150°
                        const angle6 = (5 * Math.PI) / 6;
                        startX = sourcePos.x + sourceRadius * Math.cos(angle6);
                        startY = sourcePos.y + sourceRadius * Math.sin(angle6);
                        endX = sourcePos.x + sourceRadius * Math.cos(angle6 + Math.PI);
                        endY = sourcePos.y + sourceRadius * Math.sin(angle6 + Math.PI);
                        break;
                  }
                  return { start: { x: startX, y: startY }, end: { x: endX, y: endY } };
              }
  
  const sourcePos = nodePositions[d.source];
  const targetPos = nodePositions[d.target];
  const sourceRadius = Math.log10(nodes[d.source].papers) * config.scale;
  const targetRadius = Math.log10(nodes[d.target].papers) * config.scale;
  
  const dx = targetPos.x - sourcePos.x;
  const dy = targetPos.y - sourcePos.y;
  const length = Math.sqrt(dx * dx + dy * dy);
              if (length === 0) return { start: sourcePos, end: sourcePos };
  
              const ux = dx / length;
              const uy = dy / length;
              const direction = d.source < d.target ? 1 : -1;
              const distanceFactor = d.source < d.target ? 1 : 0.3;
              const offset = { x: -uy * config.linkOffset * scaleFactor * direction * distanceFactor, y: ux * config.linkOffset * scaleFactor * direction * distanceFactor };
  
              return {
                  start: {
                      x: sourcePos.x + ux * sourceRadius + offset.x,
                      y: sourcePos.y + uy * sourceRadius + offset.y
                  },
                  end: {
                      x: targetPos.x - ux * targetRadius + offset.x,
                      y: targetPos.y - uy * targetRadius + offset.y
                  }
              };
          }
  
  function generateParallelPath(d) {
    if (d.source === d.target) {
        const node = nodePositions[d.source];
        const radius = Math.log10(nodes[d.source].papers) * config.scale;
        const loopRadiusY = radius + config.linkOffset * scaleFactor;
        const loopRadiusX = radius / 2;

        const angle = node.angle;
        const cosA = Math.cos(angle);
        const sinA = Math.sin(angle);

        const startX = node.x - (loopRadiusX-40) * cosA;
        const startY = node.y - (loopRadiusX-40) * sinA;

        const path = `
            M ${startX},${startY} 
            a ${loopRadiusX},${loopRadiusY} ${angle * 180 / Math.PI} 1,0 ${2 * loopRadiusX * cosA},${2 * loopRadiusX * sinA} 
            a ${loopRadiusX},${loopRadiusY} ${angle * 180 / Math.PI} 1,0 ${-2 * loopRadiusX * cosA},${-2 * loopRadiusX * sinA}
        `;
        return path;
    }

    const { start, end } = getLinkEndpoints(d);
    return `M ${start.x},${start.y} L ${end.x},${end.y}`;
}

  function getLabelPosition(d) {
              if (d.source === d.target) {
                  const sourcePos = nodePositions[d.source];
                  const sourceRadius = Math.log10(nodes[d.source].papers) * config.scale;
                  const loopRadiusX = sourceRadius + config.linkOffset * scaleFactor;
                  const labelOffset = -10 * scaleFactor;
          
                  switch (d.source) {
                      case 0:
                          return {
                              x: sourcePos.x ,
                              y: sourcePos.y - sourceRadius - loopRadiusX - labelOffset -0* scaleFactor
                          };
                      case 1:
                          return {
                              x: sourcePos.x + sourceRadius + loopRadiusX + labelOffset -15* scaleFactor,
                              y: sourcePos.y -50 * scaleFactor
                          };
                      case 2:
                        return {
                            x: sourcePos.x + 70 * scaleFactor,
                            y: sourcePos.y + sourceRadius + loopRadiusX + labelOffset -70 * scaleFactor
                        };
                      case 3:
                          return {
                              x: sourcePos.x + 30 * scaleFactor,
                              y: sourcePos.y + sourceRadius + loopRadiusX + labelOffset - 25 * scaleFactor
                          };
                      case 4:
                          return {
                              x: sourcePos.x - sourceRadius - loopRadiusX - labelOffset + 40 * scaleFactor,
                              y: sourcePos.y + 40 * scaleFactor
                          };
                      case 5:
                          return {
                              x: sourcePos.x - sourceRadius - loopRadiusX - labelOffset - 0 * scaleFactor,
                              y: sourcePos.y
                          };
                      case 6:
                          return {
                              x: sourcePos.x - sourceRadius - loopRadiusX - labelOffset + 30 * scaleFactor,
                              y: sourcePos.y - 50 * scaleFactor
                          };
                      default:
                          const loopAngle = nodePositions[d.source].angle;
                          return {
                              x: sourcePos.x + Math.cos(loopAngle) * labelOffset,
                              y: sourcePos.y + Math.sin(loopAngle) * labelOffset
                          };
                  }
              }
          
  
              const { start, end } = getLinkEndpoints(d);
              const pathDx = end.x - start.x;
              const pathDy = end.y - start.y;
              const pathLength = Math.sqrt(pathDx ** 2 + pathDy ** 2);
              
              if (pathLength === 0) return { x: start.x, y: start.y };
          
              const ux = pathDx / pathLength;
              const uy = pathDy / pathLength;
              const perpX = -uy;
              const perpY = ux;
              const mid = { x: (start.x + end.x) / 2, y: (start.y + end.y) / 2 };
  
              const labelOffset = config.linkOffset * 1.2 * scaleFactor;
              const strokeWidth = strokeScale(d.weight); 
              const adjustedLabelOffset = labelOffset + strokeWidth / 2; 
          
              const xOffset = 2;
          
              const alignOffset = getAlignmentOffset(d);
          
              return {
                  x: mid.x + perpX * adjustedLabelOffset + 10 - xOffset + alignOffset.x,
                  y: mid.y + perpY * adjustedLabelOffset - 10 + alignOffset.y
              };
          }
          
  function getAlignmentOffset(d) {
    const labelPositions = {
    'CDDG-BDNI': {'x': 0, 'y': 0},
    'CDDG-MIRG': {'x': 0, 'y': 0},
    'CDDG-CVHI': {'x': 0, 'y': 0},
    'CDDG-MIRC': {'x': 0, 'y': 0},
    'CDDG-SNCP': {'x': 0, 'y': 0},
    'CDDG-MISG': {'x': 0, 'y': 0},
    'BDNI-CDDG': {'x': 0, 'y': 0},
    'BDNI-MIRG': {'x': 0, 'y': 0},
    'BDNI-CVHI': {'x': 0, 'y': 0},
    'BDNI-MIRC': {'x': 0, 'y': 0},
    'BDNI-SNCP': {'x': 0, 'y': 0},
    'BDNI-MISG': {'x': 0, 'y': 0},
    'MIRG-CDDG': {'x': 0, 'y': 0},
    'MIRG-BDNI': {'x': 0, 'y': 0},
    'MIRG-CVHI': {'x': 0, 'y': 0},
    'MIRG-MIRC': {'x': 0, 'y': 0},
    'MIRG-SNCP': {'x': 0, 'y': 0},
    'MIRG-MISG': {'x': 0, 'y': 0},
    'CVHI-CDDG': {'x': 0, 'y': 0},
    'CVHI-BDNI': {'x': 0, 'y': 0},
    'CVHI-MIRG': {'x': 0, 'y': 0},
    'CVHI-MIRC': {'x': 0, 'y': 0},
    'CVHI-SNCP': {'x': 0, 'y': 0},
    'CVHI-MISG': {'x': 0, 'y': 0},
    'MIRC-CDDG': {'x': 0, 'y': 0},
    'MIRC-BDNI': {'x': 0, 'y': 0},
    'MIRC-MIRG': {'x': 0, 'y': 0},
    'MIRC-CVHI': {'x': 0, 'y': 0},
    'MIRC-SNCP': {'x': 0, 'y': 0},
    'MIRC-MISG': {'x': 0, 'y': 0},
    'SNCP-CDDG': {'x': 0, 'y': 0},
    'SNCP-BDNI': {'x': 0, 'y': 0},
    'SNCP-MIRG': {'x': 0, 'y': 0},
    'SNCP-CVHI': {'x': 0, 'y': 0},
    'SNCP-MIRC': {'x': 0, 'y': 0},
    'SNCP-MISG': {'x': 0, 'y': 0},
    'MISG-CDDG': {'x': 0, 'y': 0},
    'MISG-BDNI': {'x': 0, 'y': 0},
    'MISG-MIRG': {'x': 0, 'y': 0},
    'MISG-CVHI': {'x': 0, 'y': 0},
    'MISG-MIRC': {'x': 0, 'y': 0},
    'MISG-SNCP': {'x': 0, 'y': 0}
};
          
              switch (`${nodes[d.source].name}-${nodes[d.target].name}`) {
                  case 'NLP-AI':
                      return { x: 0, y: 0 }; 
                  case 'AI-ML':
                      return { x: -3.5, y: 2 }; 
                  case 'Web-ML':
                      return { x: 0, y: 0 }; 
                  case 'CV-NLP':
                      return { x: 0, y: -5 }; 
                  case 'AI-Web':
                      return { x: 0, y: 0 }; 
                  case 'CV-AI':
                      return { x: 0, y: 0 }; 
                  case 'Web-AI':
                      return { x: 0, y: -1 }; 
                  case 'CV-ML':
                      return { x: -2, y: 0 };
                  case 'AI-NLP':
                      return { x: -1, y: -4 }; 
                  case 'NLP-Web':
                      return { x: 0, y: 2 }; 
                  case 'NLP-ML':
                      return { x: 0, y: -3 }; 
                  case 'Web-NLP':
                      return { x: 0, y: 0 }; 
                  case 'ML-CV':
                      return { x: 0, y: 0 }; 
                  case 'NLP-ML':
                      return { x: 0, y: 0 }; 
                  case 'ML-NLP':
                      return { x: 0, y: 0 }; 
                  case 'CV-Web':
                      return { x: 1, y: 0 }; 
                  case 'Web-CV':
                      return { x: 0.5, y: -4 }; 
                  case 'ML-AI':
                      return { x: 0, y: -4 };
                  case 'NLP-CV':
                        return { x: 0, y: -4 }; 
                  case 'ML-Web':
                        return { x: 0, y: -2 }; 
                  default:
                      return { x: 0, y: 0 };
              }
          }    
  
  function calculatePentagonPositions(centerX, centerY, radius) {
              return nodes.map((_, i) => {
                  const angle = -Math.PI / 2 + i * 2 * Math.PI / 7;
                  return { x: centerX + radius * Math.cos(angle), y: centerY + radius * Math.sin(angle), angle };
              });
          }
              
