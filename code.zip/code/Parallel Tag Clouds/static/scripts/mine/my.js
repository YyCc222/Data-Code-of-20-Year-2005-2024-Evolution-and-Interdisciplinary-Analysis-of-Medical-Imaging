const window_num = 6;
const start_date = '2005-01-01';
const end_date = '2024-12-31';
const only_phrase = 1;
let svg_width = 2800;
const svg_height = 1600;
const min_col_width = 100;
const text_gap = 8;
const colors = ["#4e79a7", "#f28e2c", "#e15759", "#76b7b2", "#59a14f", "#edc949", "#af7aa1", "#ff9da7", "#9c755f", "#bab0ab"];
const col_width = Math.max(min_col_width, svg_width / window_num);
let sort_type = 'G2';

const Topics = [
    {name: 'Cancer Detection and Diagnosis(CDD)', color: '#4d78a6'},
    {name: 'Brain Disorders and Neuroimaging(BDN)', color: '#f08d2c'},
    {name: 'Medical Image Registration(MI Reg)', color: '#df5658'},
    {name: 'Cardiovascular and Hemodynamic Imaging(CHI)', color: '#75b6b1'},
    {name: 'Medical Image Reconstruction(MI Rec)', color: '#58a04e'},
    {name: 'Surgical Navigation and Clinical Practice(SNCP)', color: '#ebc748'},
    {name: 'Medical Image Segmentation(MIS)', color: '#ae79a0'}
];

const svg = d3.select('body')
    .append('svg')
    .attr('width', svg_width)
    .attr('height', svg_height);

const line = d3.line().x((d) => d[0]).y((d) => d[1]);
let all_texts, focus_texts;
let all_paths, focus_paths;
const area_data = [];

const menu = [
    {
        title: 'Sort by G2',
        action: function () {
            d3.selectAll('.col_g')
                .each(function () {
                    d3.select(this).selectAll('.text_g')
                        .transition()
                        .duration(1000)
                        .attr('transform', d => `translate(0, ${d.y1})`);
                });
            sort_type = 'G2';
            all_texts = undefined;
            all_paths = undefined;
            menu[0]['disabled'] = true;
            menu[1]['disabled'] = false;
            update_paths();
            update_areas();
        },
        disabled: true
    },
    {
        title: 'Sort by Topic',
        action: function () {
            d3.selectAll('.col_g')
                .each(function () {
                    d3.select(this).selectAll('.text_g')
                        .transition()
                        .duration(1000)
                        .attr('transform', d => `translate(0, ${d.y2})`);
                });
            sort_type = 'Topic';
            all_texts = undefined;
            all_paths = undefined;
            menu[0]['disabled'] = false;
            menu[1]['disabled'] = true;
            update_paths();
            update_areas();
        },
        disabled: false
    }
];

svg.append('rect')
    .attr('width', svg_width)
    .attr('height', svg_height)
    .attr('fill', 'white')
    .attr('stroke', '#888')
    .on('contextmenu', d3.contextMenu(menu));

const areas_g = svg.append('g').attr('id', 'areas_g');
const paths_g = svg.append('g').attr('id', 'paths_g');
const cols_g = svg.append('g').attr('id', 'cols_g');

const gradientStops = [
    {'pos': "0%", 'opc': 1},
    {'pos': "20%", 'opc': 0},
    {'pos': "80%", 'opc': 0},
    {'pos': "100%", 'opc': 1},
];
const texts2data = new Map();

svg.append("defs")
    .append("linearGradient")
    .attr("id", "gradient")
    .selectAll("stop")
    .data(gradientStops)
    .enter()
    .append("stop")
    .attr("offset", d => d.pos)
    .attr("stop-color", "#6ea4f1")
    .attr("stop-opacity", d => d.opc);

let phrasesNumData = {};
d3.json('../static/data/phrases_num.json').then(data => {
    phrasesNumData = data;
});
const popup = d3.select('body').append('div')
    .attr('id', 'word-popup')
    .style('position', 'absolute')
    .style('background', 'white')
    .style('border', '1px solid #aaa')
    .style('padding', '10px')
    .style('box-shadow', '0 2px 5px rgba(0,0,0,0.3)')
    .style('pointer-events', 'auto')
    .style('display', 'none');
function showWordPopup(word, event) {
    if (!(word in phrasesNumData)) {
        popup.style('display', 'none');
        return;
    }
    const freqData = phrasesNumData[word];

    const START_YEAR = 2005;
    const END_YEAR = 2024;
    const years = d3.range(START_YEAR, END_YEAR + 1);
    const yearCounts = years.map(y => ({
        year: new Date(y, 0, 1),
        count: +freqData[y] || 0
    }));

    const width = 800;
    const height = 400;
    const margin = {top: 0.15*height, right: 0.08*width, bottom: 0.15*height, left: 0.08*width};

    popup.html('').style('display', 'block');
    const svgRect = svg.node().getBoundingClientRect();
    const pageX = event.clientX - svgRect.left + window.scrollX;
    const pageY = event.clientY - svgRect.top + window.scrollY;
    popup.style('left', (pageX + 10) + 'px')
         .style('top', (pageY + 10) + 'px')
         .style('width', width + 'px')
         .style('height', height + 'px');

    const svgPopup = popup.append('svg')
        .attr('width', width)
        .attr('height', height);

    const x = d3.scaleTime()
        .domain([new Date(START_YEAR, 0, 1), new Date(END_YEAR + 1, 0, 1)])
        .range([margin.left, width - margin.right]);

    const y = d3.scaleLinear()
        .domain([0, d3.max(yearCounts, d => d.count)]).nice()
        .range([height - margin.bottom, margin.top]);

    const tickYears = [2005, 2010, 2015, 2020, 2025].map(y => new Date(y, 0, 1));
    svgPopup.append('g')
        .attr('transform', `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(x).tickValues(tickYears).tickFormat(d3.timeFormat("%Y")))
        .attr('font-size', '20px');

    svgPopup.append('g')
        .attr('transform', `translate(${margin.left},0)`)
        .call(d3.axisLeft(y).ticks(5))
        .attr('font-size', '20px');

    const lineGen = d3.line()
        .x(d => x(d.year))
        .y(d => y(d.count));

    svgPopup.append('path')
        .datum(yearCounts)
        .attr('fill', 'none')
        .attr('stroke', '#4e79a7')
        .attr('stroke-width', 4)
        .attr('d', lineGen);

    svgPopup.selectAll('.dot')
        .data(yearCounts)
        .enter()
        .append('circle')
        .attr('class', 'dot')
        .attr('cx', d => x(d.year))
        .attr('cy', d => y(d.count))
        .attr('r', 3);

    svgPopup.append('text')
        .attr('x', width / 2)
        .attr('y', margin.top / 2)
        .attr('text-anchor', 'middle')
        .attr('font-weight', 'bold')
        .attr('font-size', '28px')
        .text(`Yearly Frequency of: ${word}`);
}

svg.on('click', () => {
    popup.style('display', 'none');
});


d3.json('../static/data/handled_data.json').then(function (data) {
    const values = data.map(d => d.words.map(d => d.value)).flat();
    const domain = d3.extent(values);
    const value2size = d3.scaleLog()
        .domain(domain)
        .range([18, 30]);

    cols_g.selectAll('.col_g')
        .data(data)
        .enter()
        .append('g')
        .attr('class', 'col_g')
        .attr('transform', (d, i) => `translate(${i * (col_width)}, 0)`)
        .each(function (group_d, group_id) {
            const col_g = d3.select(this);
            col_g.append('text')
                .attr('alignment-baseline', 'hanging')
                .attr('text-anchor', 'middle')
                .attr('font-size', 30)
                .attr('x', col_width / 2)
                .attr('y', 0)
                .attr('font-weight', 'bolder')
                .attr('front', 'Space Mono')
                .attr('opacity',0)
                .text(group_d.window.replace(/2023-/g, ''));

            let y = 15;
            let trunc_index = 0;
            col_g.selectAll('.text_g')
                .data(group_d.words)
                .enter()
                .append('g')
                .attr('class', 'text_g')
                .each(function (d, i) {
                    const text_g = d3.select(this);
                    d.x = col_width / 2;
                    const text = text_g.append('text')
                        .attr('class', 'text')
                        .attr('alignment-baseline', 'middle')
                        .attr('text-anchor', 'middle')
                        .attr('x', col_width / 2)
                        .attr('font-size', value2size(d.value))
                        .attr('font', 'Helvetica')
                        .attr('fill', 'black')
                        .style('pointer-events', 'all')
                        .on('mouseover', function (t) {
                            if (!all_texts) all_texts = svg.selectAll('.text');
                            focus_texts = all_texts
                                .filter(w => w.word === t.word)
                                .attr('font-weight', 'bolder');
                            if (!all_paths) all_paths = svg.selectAll('.path');
                            focus_paths = all_paths.filter(p => p.word === t.word)
                                .attr('stroke', '#ff6b6b')
                                .raise();
                        })
                        .on('mouseout', function (t) {
                            if (focus_texts) focus_texts.attr('font-weight', 'normal');
                            if (focus_paths) focus_paths.attr('stroke', 'url(#gradient)');
                        })
                        .text(t => t.word)
                        .on('click', function (d, i) {
                            d3.event.stopPropagation();
                            showWordPopup(d.word,d3.event);
                        });
                    const box = text.node().getBBox();
                    d.width = box.width;
                    d.height = box.height;
                    d.group_id = group_id;
                    d.topic_id = d['pros'][0].topic_id;
                    y += d.height + text_gap;
                    d.y1 = y - d.height / 2;
                    text_g.attr('transform', `translate(0, ${d.y1})`);
                    if ((y + d.height / 2 + 3) < svg_height) trunc_index = i + 1;
                });

            col_g.selectAll('.text_g').filter(d => (d.y1 + d.height + 3) >= svg_height).remove();
            group_d.words = group_d.words.slice(0, trunc_index);
            for (const d of group_d.words) {
                const temp = texts2data.get(d.word);
                if (temp) temp.push(d)
                else texts2data.set(d.word, [d]);
                d.left_x = group_id * col_width + col_width / 2 - d.width / 2 - 2;
                d.right_x = group_id * col_width + col_width / 2 + d.width / 2 + 2;
            }

            col_g.selectAll('.text_g')
                .each(function () {
                    d3.select(this).append('g')
                        .attr('class', 'bar_g')
                        .attr('transform', d => `translate(${col_width / 2}, ${d.height / 2})`)
                        .each(function (d) {
                            const pros = d['pros'];
                            pros.push({'topic_id': -1, 'pro': Math.max(1 - d3.sum(pros, d => d.pro), 0)});
                            const bar_data = [];
                            let acc_p = 0
                            for (const p of pros) {
                                const x = acc_p * d.width - d.width / 2;
                                acc_p += p.pro;
                                const color = p.topic_id === -1 ? '#888' : Topics[p.topic_id].color;
                                bar_data.push({'x': x, 'width': p.pro * d.width, 'color': color});
                            }
                            d3.select(this)
                                .selectAll('rect')
                                .data(bar_data)
                                .enter()
                                .append('rect')
                                .attr('x', d => d.x)
                                .attr('y', -2)
                                .attr('width', d => d.width)
                                .attr('height', 3)
                                .attr('fill', d => d.color);
                        });

                })

            y = 15;
            group_d.words.sort((a, b) => (a.topic_id - b.topic_id));
            for (const d of group_d.words) {
                y += d.height + text_gap;
                d.y2 = y - d.height / 2;
            }
            group_d.words.push({'topic_id': -1});
            let area = [];
            let center_x = group_id * col_width + col_width / 2;
            for (let i = 1; i < group_d.words.length; i++) {
                const last = group_d.words[i - 1];
                const cur = group_d.words[i];

                if (last.topic_id === cur.topic_id) {
                    const up = [last.left_x - 2, last.y2 - last.height / 2];
                    up.width = last.width;
                    area.push(up);
                    const down = [last.left_x - 2, last.y2 + last.height / 2 + text_gap  / 2];
                    down.width = last.width;
                    area.push(down);
                } else {
                    const up = [last.left_x - 2, last.y2 - last.height / 2];
                    up.width = last.width;
                    area.push(up);
                    const down = [last.left_x - 2, last.y2 + last.height / 2 + text_gap  / 2];
                    down.width = last.width;
                    area.push(down);
                    const down_center = [center_x, down[1] + 2];
                    area.push(down_center);
                    for (let j = area.length - 2; j >= 0; j--) {
                        const p = area[j];
                        area.push([p[0] + p.width + 6, p[1]]);
                    }
                    const up_center = [center_x, area[area.length - 1][1] - 3];
                    area.push(up_center);
                    area.topic_id = last.topic_id;
                    area_data.push(area);
                    area = [];
                }
            }
            group_d.words.pop();
        });

    update_paths();
    update_areas();
});

function update_paths() {
    const line_data = [];
    for (const [text, data] of texts2data) {
        if (data.length >= 2) {
            for (let i = 1; i < data.length; i++) {
                const cur_d = data[i];
                const last_d = data[i - 1];
                if (cur_d.group_id === last_d.group_id + 1) {
                    const points = sort_type === 'G2' ? [[last_d.right_x, last_d.y1], [cur_d.left_x, cur_d.y1]]
                        : [[last_d.right_x, last_d.y2], [cur_d.left_x, cur_d.y2]];
                    points.word = text;
                    line_data.push(points);
                }
            }
        }
    }
    paths_g.selectAll('*').remove();
    if (sort_type === 'Topic') return;
    paths_g.selectAll('path')
        .data(line_data)
        .enter()
        .append('path')
        .attr('class', 'path')
        .attr('stroke-width', 5)
        .attr('d', d => line(d))
        .attr('stroke', 'url(#gradient)')
        .transition()
        .delay(800)
        .duration(500)
        .attr('opacity', 1);
}

function update_areas() {
    const line = d3.line().curve(d3.curveCatmullRomClosed.alpha(0.8));
    areas_g.selectAll('*').remove();
    if (sort_type === 'G2') return;
    areas_g.selectAll('.area')
        .data(area_data)
        .enter()
        .append('path')
        .attr('class', 'area')
        .attr('fill', d => Topics[d.topic_id].color)
        .attr('d', d => line(d))
        .attr('fill-opacity', 0)
        .transition()
        .delay(1000)
        .duration(500)
        .attr('fill-opacity', 0.3);
}