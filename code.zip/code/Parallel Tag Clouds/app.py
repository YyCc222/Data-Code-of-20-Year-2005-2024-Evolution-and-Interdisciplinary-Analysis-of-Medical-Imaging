from flask import Flask, render_template, request, redirect, url_for
import json
import numpy as np
from datetime import datetime
from collections import defaultdict, Counter
from util import *
import os

app = Flask(__name__)

data_path = r'static\data'
with open(os.path.join(data_path, 'corpus.txt'), 'r', encoding='utf-8') as f:
    corpus = [line.strip().split(',') for line in f]
with open(os.path.join(data_path, 'data.json'), 'r', encoding='utf-8') as f:
    dates = []
    for item in json.load(f):
        dates.append(item['time'])

num_topics = 7

def get_topic_pro(array, n=3):
    sorted_indices = np.argsort(-array)
    top_n_values = array[sorted_indices[:n]]
    top_n_indices = sorted_indices[:n]
    pros = []
    for i, v in zip(top_n_indices, top_n_values):
        pros.append({'topic_id': int(i), 'pro': round(float(v), 3)})
    return pros


@app.route('/')
def hello_world():
    return redirect(url_for('index'))


@app.route('/index')
def index():
    return render_template('index.html')


@app.route('/get_data', methods=['POST'])

def get_data():
    window_num = int(request.form['window_num'])
    start_date = datetime.strptime('2005-01-01', '%Y-%m-%d')
    end_date = datetime.strptime('2024-12-31', '%Y-%m-%d')
    total_years = (end_date.year - start_date.year + 1)
    window_length = total_years // window_num
    top_n = 150
    windows = []
    for i in range(window_num):
        window_start = start_date.replace(year=start_date.year + i * window_length)
        window_end = end_date if i == window_num - 1 else start_date.replace(year=start_date.year + (i + 1) * window_length -1)
        window_start_str = window_start.strftime("%Y")
        window_end_str = window_end.strftime("%Y")
        window_str = f"{window_start_str} ~ {window_end_str}"
        windows.append(window_str)
    print(windows)

    corpus_counter = Counter()
    for phrases in corpus:
        corpus_counter.update(phrases)

    window2results = defaultdict(list)
    with open(data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    results = []
    for window_id, window_str in enumerate(windows):
        window_start_year = int(window_str.split(' ~ ')[0])
        window_end_year = int(window_str.split(' ~ ')[1])
        window_papers = []
        for paper in data:
            try:
                date = datetime.strptime(paper['time'], '%Y-%m-%d')
                if window_start_year <= date.year <= window_end_year:
                    window_papers.append(paper)
            except ValueError:
                print(f"Invalid date: {paper['time']}")
        word_to_topic_probs = defaultdict(lambda: defaultdict(float))
        for paper in window_papers:
            paper_id = paper['id']
            topic_id = paper['topic_id']
            for phrase in corpus[paper_id]:
                word_to_topic_probs[phrase][topic_id] += 1
        words = []
        for paper in window_papers:
            paper_id = paper['id']
            target_counter = Counter(corpus[paper_id])
            significant_phrases = g2_statistics(corpus_counter, target_counter)
            for phrase, g2_value in significant_phrases:
                if phrase not in word_to_topic_probs:
                    continue
                topic_probs = word_to_topic_probs[phrase]
                total_count = sum(topic_probs.values())
                pros = [{"topic_id": topic_id, "pro": prob / total_count} for topic_id, prob in
                        topic_probs.items()]
                pros = sorted(pros, key=lambda x: x['pro'], reverse=True)[:3]
                words.append({"word": phrase, "value": round(g2_value, 2), "pros": pros})
        words = sorted(words, key=lambda x: x['value'], reverse=True)[:top_n]
        print(words)
        results.append({"window": window_str, "words": words})

    return json.dumps(results)


if __name__ == '__main__':
    app.run(debug=True, port=8029)
