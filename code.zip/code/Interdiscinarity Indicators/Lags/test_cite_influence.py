import json
import matplotlib.pyplot as plt
import numpy as np

with open("data\ALL_diversity.json", "r", encoding="utf-8") as f:
    data_div = json.load(f)

with open("data\ALL_field_Gini.json", "r", encoding="utf-8") as f:
    data_gini = json.load(f)

def plot_indicator(data_raw, title, ylabel, save_name):
    data_sorted = sorted(data_raw, key=lambda x: int(x["year"]))
    years = [int(d["year"]) for d in data_sorted]
    values = [d["revenue"] for d in data_sorted]

    window = 3
    values_smooth = np.convolve(values, np.ones(window) / window, mode='valid')
    years_smooth = years[window - 1:]
    exclude_last_n = 2
    years_exclude = years[:-exclude_last_n]
    values_exclude = values[:-exclude_last_n]
    plt.figure(figsize=(8, 6))
    plt.plot(years, values, marker='o', label="Original values")
    plt.plot(years_smooth, values_smooth, marker='s', linestyle='--', label="3-year Moving Average")
    plt.plot(years_exclude, values_exclude, marker='^', linestyle=':', label="Exclude last 2 years")

    plt.xlabel("Year")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.grid(True, linestyle="--", color="lightgray", linewidth=0.7)
    years_tick = [y for y in years if y % 5 == 0]
    plt.xticks(years_tick)

    latest_raw = values[-1]
    latest_smooth = values_smooth[-1]
    gap = latest_raw - latest_smooth
    gap_pct = gap / latest_smooth * 100
    print(f"{title} — Latest raw value: {latest_raw:.3f}, "
          f"Moving average: {latest_smooth:.3f}, "
          f"Gap: {gap:.3f} ({gap_pct:+.1f}%)")
    plt.savefig(save_name, dpi=400, bbox_inches='tight')
    plt.close()
    print(f"Saved: {save_name}")

# Plot Diversity
plot_indicator(
    data_raw=data_div,
    title="Diversity Trend and Citation Lag Evaluation",
    ylabel="Diversity",
    save_name="Diversity_trend_citation_lag.png"
)

# Plot Balance / Gini
plot_indicator(
    data_raw=data_gini,
    title="Balance (Gini) Trend and Citation Lag Evaluation",
    ylabel="Balance (Gini)",
    save_name="Gini_trend_citation_lag.png"
)


