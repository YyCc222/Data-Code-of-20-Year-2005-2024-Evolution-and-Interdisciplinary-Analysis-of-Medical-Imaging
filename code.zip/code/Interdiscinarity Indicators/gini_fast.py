import os
from collections import defaultdict
try:
    import orjson as json
except ImportError:
    import json

def build_index(*datasets):
    index = {}
    for dataset in datasets:
        for p in dataset:
            if not isinstance(p, dict):
                continue
            pid = p.get('id')
            if pid:
                index[pid] = p
                index[pid.split('/')[-1]] = p
    return index

def search_papers(index, pid, time_range):
    p = index.get(pid) or index.get(pid.split('/')[-1])
    if p and time_range[0] <= p['publication_year'] < time_range[1]:
        return p
    return None

def time_mode(time_judge, b_time, e_time):
    time_windows = []
    if time_judge == 0:
        for i in range(b_time, e_time + 1):
            time_windows.append([i, i + 1])
    else:
        for i in range(b_time, e_time - 3, 5):
            time_windows.append([i, i + 5])
    if time_judge == 0 and e_time not in [w[0] for w in time_windows]:
        time_windows.append([e_time, e_time + 1])
    elif time_judge == 1 and e_time - 4 not in [w[0] for w in time_windows]:
        time_windows.append([e_time - 4, e_time])
    print("time windows:", time_windows)
    return time_windows

def load_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.loads(f.read()) if 'orjson' in str(json) else json.load(f)

reference_data = load_json(r"data/references.json")
c_ids_data = load_json(r"data/citings_id.json")
citing_data = load_json(r"data/citings.json")

b_time = 2005
e_time = 2024
time_judge = int(input('please input your time mode (0=year, 1=5year): '))
time_windows = time_mode(time_judge, b_time, e_time)

topics = {
    '0': 'CDDG', '1': 'BDNI', '2': 'MIRG', '3': 'CVHI', '4': 'MIRC', '5': 'SNCP', '6': 'MISG'
}

fields = {
    'Biochemistry, Genetics and Molecular Biology': 0, 'Computer Science': 1, 'Mathematics': 2,
    'Medicine': 3, 'Neuroscience': 4, 'Engineering': 5, 'Physics and Astronomy': 6, 'Dentistry': 7,
    'Immunology and Microbiology': 8, 'Decision Sciences': 9, 'Earth and Planetary Sciences': 10,
    'Social Sciences': 11, 'Environmental Science': 12, 'Materials Science': 13, 'Psychology': 14,
    'Health Professions': 15, 'Chemistry': 16, 'Arts and Humanities': 17, 'Economics, Econometrics and Finance': 18,
    'Agricultural and Biological Sciences': 19, 'Nursing': 20
}

file_path = 'data/topics'
r_final_data = []
c_final_data = []

for filename in os.listdir(file_path):
    file = os.path.join(file_path, filename)
    with open(file, 'r', encoding='utf-8') as f:
        papers = json.loads(f.read()) if 'orjson' in str(json) else json.load(f)

    ref_index = build_index(reference_data, citing_data, papers)

    for time in time_windows:
        topic_data = {
            "format": topics[filename.split('.')[0]],
            "year": str(time[0]) + ("~" + str(time[1]-1) if time_judge==1 else ""),
            "revenue": 0
        }

        cij1_cji2 = defaultdict(lambda: defaultdict(int))
        cij2_cji1 = defaultdict(lambda: defaultdict(int))

        for paper in papers:
            if not (time[0] <= paper['publication_year'] < time[1]):
                continue
            primary_topic = paper.get('primary_topic')
            if not primary_topic or not isinstance(primary_topic, dict):
                continue
            field_i = primary_topic.get('field', {}).get('display_name')
            if not field_i:
                continue

            # cij1 & cji2
            for r_id in paper.get('referenced_works', []):
                r_paper = search_papers(ref_index, r_id, time)
                if not r_paper:
                    continue
                r_primary = r_paper.get('primary_topic')
                field_j = r_primary.get('field', {}).get('display_name') if r_primary else None
                if not field_j:
                    continue
                cij1_cji2[field_i][field_j] += 1

            # cij2 & cji1
            citing_works = c_ids_data.get(paper['id'].split('/')[-1], [])
            for c_id in citing_works:
                c_paper = search_papers(ref_index, c_id, time)
                if not c_paper:
                    continue
                c_primary = c_paper.get('primary_topic')
                field_j = c_primary.get('field', {}).get('display_name') if c_primary else None
                if not field_j:
                    continue
                cij2_cji1[field_i][field_j] += 1

        # TC / TR / c
        c = defaultdict(int)
        TC = defaultdict(int)
        TR = defaultdict(int)
        total_TC = 0
        total_TR = 0

        for field_i in list(cij1_cji2.keys()):
            TCi = 0
            TRi = 0
            for field_j in list(cij1_cji2[field_i].keys()):
                key = f"{field_i}_{field_j}"
                cij = cij1_cji2[field_i][field_j] + cij2_cji1.get(field_j, {}).get(field_i, 0)
                cji = cij1_cji2.get(field_j, {}).get(field_i, 0) + cij2_cji1[field_i][field_j]
                c[key] = cij
                TCi += cij
                TRi += cji
            TC[field_i] = TCi
            TR[field_i] = TRi
            total_TC += TCi
            total_TR += TRi

        # revenue - Gini
        sum_num = 0
        SUM_NUM = 0
        n = 21
        for key in c:
            fi, fj = key.split('_')
            if fi == fj:
                continue
            xi, xj = TC.get(fi, 0), TC.get(fj, 0)
            Xi, Xj = TR.get(fi, 0), TR.get(fj, 0)
            sum_num += abs(xi - xj)
            SUM_NUM += abs(Xi - Xj)

        r_revenue = -1 if total_TC==0 else sum_num/(2*n*total_TC)
        c_revenue = -1 if total_TR==0 else SUM_NUM/(2*n*total_TR)

        topic_data['revenue'] = r_revenue
        r_final_data.append(topic_data.copy())
        topic_data['revenue'] = c_revenue
        c_final_data.append(topic_data.copy())

def save_json(data, file_name):
    if 'orjson' in str(json):
        with open(file_name, 'wb') as fw:
            fw.write(json.dumps(data, option=json.OPT_INDENT_2))
    else:
        with open(file_name, 'w', encoding='utf-8') as fw:
            json.dump(data, fw, ensure_ascii=False, indent=4)

save_json(r_final_data, 'five_year_r_gini.json')
save_json(c_final_data, 'five_year_c_gini.json')

'''
for time in time_windows:
    data = {
        "format": "ALL", 
        "year": str(time[0]) + ("~" + str(time[1] - 1) if time_judge == 1 else ""),
        "revenue": 0
    }

    cij1_cji2 = defaultdict(lambda: defaultdict(int))
    cij2_cji1 = defaultdict(lambda: defaultdict(int))

    for paper in all_papers:
        if not (time[0] <= paper['publication_year'] < time[1]):
            continue
        primary_topic = paper.get('primary_topic')
        if not primary_topic:
            continue
        field_i = primary_topic.get('field', {}).get('display_name')
        if not field_i:
            continue

        for r_id in paper.get('referenced_works', []):
            r_paper = search_papers(field_index, r_id, time)
            if r_paper is None:
                continue  
            primary = r_paper.get('primary_topic')
            if not primary:
                continue
            field_info = primary.get('field')
            if not field_info:
                continue
            r_field = field_info.get('display_name')
            if not r_field:
                continue
            cij1_cji2[field_i][r_field] += 1

        citing_works = c_ids_data.get(paper['id'].split('/')[-1], [])
        for c_id in citing_works:
            c_paper = search_papers(field_index, c_id, time)
            if c_paper is None:
                continue 
            primary = c_paper.get('primary_topic')
            if not primary:
                continue
            field_info = primary.get('field')
            if not field_info:
                continue
            c_field = field_info.get('display_name')
            if not c_field:
                continue
            cij2_cji1[field_i][c_field] += 1

    c = defaultdict(int)
    TC = defaultdict(int)
    TR = defaultdict(int)
    total_TC = total_TR = 0

    for fi in cij1_cji2.keys():
        TCi = TRi = 0
        for fj in cij1_cji2[fi].keys():
            key = f"{fi}_{fj}"
            cij = cij1_cji2[fi][fj] + cij2_cji1.get(fj, {}).get(fi, 0)
            cji = cij1_cji2.get(fj, {}).get(fi, 0) + cij2_cji1[fi][fj]
            c[key] = cij
            TCi += cij
            TRi += cji
        TC[fi] = TCi
        TR[fi] = TRi
        total_TC += TCi
        total_TR += TRi

    sum_num = SUM_NUM = 0
    n = 21

    for key in c:
        fi, fj = key.split('_')
        if fi == fj:
            continue
        xi, xj = TC.get(fi, 0), TC.get(fj, 0)
        Xi, Xj = TR.get(fi, 0), TR.get(fj, 0)
        sum_num += abs(xi - xj)
        SUM_NUM += abs(Xi - Xj)

    r_revenue = -1 if total_TC == 0 else sum_num / (2 * n * total_TC)
    data['revenue'] = r_revenue
    final_data.append(data)

def save_json(data, file_name):
    try:
        import orjson
        with open(file_name, 'wb') as fw:
            fw.write(orjson.dumps(data, option=orjson.OPT_INDENT_2))
    except ImportError:
        import json
        with open(file_name, 'w', encoding='utf-8') as fw:
            json.dump(data, fw, ensure_ascii=False, indent=4)
save_json(final_data, 'Lags/ALL_field_Gini.json')
'''