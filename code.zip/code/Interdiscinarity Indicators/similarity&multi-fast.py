import os
import math
import json
from collections import defaultdict, Counter

try:
    import orjson as fastjson
except ImportError:
    fastjson = json

def build_index(*datasets):
    index = {}
    for dataset in datasets:
        for p in dataset:
            index[p['id']] = p
            index[p['id'].split('/')[-1]] = p
    return index

def search_papers(index, pid, time_range):
    p = index.get(pid) or index.get(pid.split('/')[-1])
    if p and time_range[0] <= p['publication_year'] < time_range[1]:
        return p
    return None

def time_mode(time_judge, b_time, e_time):
    time_windows = []
    if time_judge == 0:
        for i in range(b_time, e_time + 1):
            time_windows.append([i, i + 1])
    else:
        for i in range(b_time, e_time - 3, 5):
            time_windows.append([i, i + 5])

    if time_judge == 0 and e_time not in [w[0] for w in time_windows]:
        time_windows.append([e_time, e_time + 1])
    elif time_judge == 1 and e_time - 4 not in [w[0] for w in time_windows]:
        time_windows.append([e_time - 4, e_time])

    print("time windows:", time_windows)
    return time_windows


with open(r"data/references.json", "r", encoding="utf-8") as r_f:
    reference_data = fastjson.loads(r_f.read())

with open(r"data/citings_id.json", "r", encoding="utf-8") as c_ids:
    c_ids_data = fastjson.loads(c_ids.read())

with open(r"data/citings.json", "r", encoding="utf-8") as c_f:
    citing_data = fastjson.loads(c_f.read())

b_time = 2005
e_time = 2024
time_judge = int(input('please input your time mode (0=year, 1=5year): '))
time_windows = time_mode(time_judge, b_time, e_time)

topics = {
    '0': 'CDDG', '1': 'BDNI', '2': 'MIRG', '3': 'CVHI',
    '4': 'MIRC', '5': 'SNCP', '6': 'MISG'
}

fields = {
    'Biochemistry, Genetics and Molecular Biology': 0, 'Computer Science': 1, 'Mathematics': 2,
    'Medicine': 3, 'Neuroscience': 4, 'Engineering': 5, 'Physics and Astronomy': 6, 'Dentistry': 7,
    'Immunology and Microbiology': 8, 'Decision Sciences': 9, 'Earth and Planetary Sciences': 10,
    'Social Sciences': 11, 'Environmental Science': 12, 'Materials Science': 13, 'Psychology': 14,
    'Health Professions': 15, 'Chemistry': 16, 'Arts and Humanities': 17, 'Economics, Econometrics and Finance': 18,
    'Agricultural and Biological Sciences': 19, 'Nursing': 20
}

file_path = 'data/topics'
final_data = []

for filename in os.listdir(file_path):
    file = os.path.join(file_path, filename)
    with open(file, encoding='utf-8') as f:
        papers = fastjson.loads(f.read())

    ref_index = build_index(reference_data, citing_data, papers)

    for time in time_windows:
        topic_data = {
            "format": topics[filename.split('.')[0]],
            "year": str(time[0]) + ("~" + str(time[1] - 1) if time_judge == 1 else ""),
            "revenue": 0
        }

        cij_counter = Counter()

        # cij
        for paper in papers:
            if not (time[0] <= paper['publication_year'] < time[1]):
                continue
            primary_topic = paper.get('primary_topic')
            if not primary_topic or not isinstance(primary_topic, dict):
                continue
            field_i = primary_topic.get('field', {}).get('display_name')
            if not field_i:
                continue

            for r_id in paper.get('referenced_works', []):
                r_paper = search_papers(ref_index, r_id, time)
                if not r_paper:
                    continue
                primary_topic = r_paper.get('primary_topic')
                if not primary_topic or not isinstance(primary_topic, dict):
                    continue
                field_j = primary_topic.get('field', {}).get('display_name')
                if not field_j:
                    continue
                cij_counter[(field_i, field_j)] += 1

            citing_works = c_ids_data.get(paper['id'].split('/')[-1], [])
            for c_id in citing_works:
                c_paper = search_papers(ref_index, c_id, time)
                if not c_paper:
                    continue
                primary_topic = c_paper.get('primary_topic')
                if not primary_topic or not isinstance(primary_topic, dict):
                    continue
                field_j = primary_topic.get('field', {}).get('display_name')
                if not field_j:
                    continue
                cij_counter[(field_j, field_i)] += 1

        # TC / TR
        TC = defaultdict(int)
        TR = defaultdict(int)
        c = {}

        for (fi, fj), val in cij_counter.items():
            cij = cij_counter[(fi, fj)] + cij_counter[(fj, fi)]
            c[f"{fi}_{fj}"] = cij
            TC[fi] += cij
            TR[fj] += cij

        total_TC = sum(TC.values())
        p = {fi: TC[fi] / total_TC for fi in TC if total_TC > 0}

        # sij
        s = {}
        k = 0
        for (fi, fj), cij in cij_counter.items():
            if fi == fj:
                continue
            TCi, TRi = TC.get(fi, 0), TR.get(fi, 0)
            TCj, TRj = TC.get(fj, 0), TR.get(fj, 0)
            if (TCi + TRi) > 0 and (TCj + TRj) > 0:
                key = f"{fi}_{fj}"
                s[key] = cij / (math.sqrt(TCi + TRi) * math.sqrt(TCj + TRj))
                k += 1

        # revenue - diversity
        revenue = 0
        if k > 0:
            for fi in p:
                sum_s = 0
                for fj in fields.keys():
                    key1 = f"{fi}_{fj}"
                    if key1 in s:
                        sum_s += (1 - s[key1])
                ave_s = sum_s / k
                revenue += ave_s * p[fi] * math.log(1 / p[fi])

        topic_data['revenue'] = revenue
        print(topic_data)
        final_data.append(topic_data)

with open('year.json', 'w', encoding='utf-8') as fw:
    fw.write(fastjson.dumps(final_data, option=fastjson.OPT_INDENT_2).decode('utf-8') if fastjson != json else json.dumps(final_data, ensure_ascii=False, indent=4))


'''
for time in time_windows:
    data = {
        "format": "ALL",
        "year": str(time[0]) + ("~" + str(time[1]-1) if time_judge==1 else ""),
        "revenue": 0
    }

    cij_counter = Counter()

    for paper in all_papers:
        if not (time[0] <= paper['publication_year'] < time[1]):
            continue
        primary_topic = paper.get('primary_topic')
        if not primary_topic:
            continue
        field_i = primary_topic.get('field', {}).get('display_name')
        if not field_i:
            continue

        for r_id in paper.get('referenced_works', []):
            r_paper = search_papers(field_index, r_id, time)
            if r_paper is None:
                continue  # 找不到就跳过
            primary = r_paper.get('primary_topic')
            if not primary:
                continue
            field_info = primary.get('field')
            if not field_info:
                continue
            r_field = field_info.get('display_name')
            if not r_field:
                continue
            cij_counter[(field_i, r_field)] += 1

        citing_works = c_ids_data.get(paper['id'].split('/')[-1], [])
        for c_id in citing_works:
            c_paper = search_papers(field_index, c_id, time)
            if c_paper is None:
                continue  
            primary = c_paper.get('primary_topic')
            if not primary:
                continue
            field_info = primary.get('field')
            if not field_info:
                continue
            c_field = field_info.get('display_name')
            if not c_field:
                continue
            cij_counter[(c_field, field_i)] += 1

    # TC / TR
    TC = defaultdict(int)
    TR = defaultdict(int)
    c = {}
    for (fi, fj), val in cij_counter.items():
        cij = cij_counter[(fi, fj)] + cij_counter.get((fj, fi), 0)
        c[f"{fi}_{fj}"] = cij
        TC[fi] += cij
        TR[fj] += cij
    total_TC = sum(TC.values())
    p = {fi: TC[fi] / total_TC for fi in TC if total_TC > 0}

    # sij
    s = {}
    k = 0
    for (fi, fj), cij in cij_counter.items():
        if fi == fj:
            continue
        TCi, TRi = TC.get(fi,0), TR.get(fi,0)
        TCj, TRj = TC.get(fj,0), TR.get(fj,0)
        if (TCi + TRi) > 0 and (TCj + TRj) > 0:
            key = f"{fi}_{fj}"
            s[key] = cij / (math.sqrt(TCi + TRi) * math.sqrt(TCj + TRj))
            k += 1

    revenue = 0
    if k > 0:
        for fi in p:
            sum_s = 0
            for fj in fields.keys():
                key1 = f"{fi}_{fj}"
                if key1 in s:
                    sum_s += (1 - s[key1])
            ave_s = sum_s / k
            revenue += ave_s * p[fi] * math.log(1/p[fi])

    data['revenue'] = revenue
    final_data.append(data)
    print(data)

with open('Lags/ALL_diversity.json', 'w', encoding='utf-8') as fw:
    json.dump(final_data, fw, ensure_ascii=False, indent=4)

'''