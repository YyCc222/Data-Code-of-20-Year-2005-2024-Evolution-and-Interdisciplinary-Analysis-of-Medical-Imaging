/**
 * Created by Administrator on 2018/12/12 0012.
 */
function CreateSelectionCircle (selection){
    return {
        element			: null,
        previousElement : null,
        currentY		: 0,
        currentX		: 0,
        originX			: 0,
        originY			: 0,
        setElement: function(ele) {
            this.previousElement = this.element;
            this.element = ele;
        },
        getNewAttributes: function() {
            let abs_x = Math.abs(this.currentX - this.originX);
            let abs_y = Math.abs(this.currentY - this.originY);
            let r = Math.sqrt(abs_x**2 + abs_y**2);
            this.element.datum().r = r;
            return {
                cx: this.originX,
                cy: this.originY,
                r: r,
                'fill-opacity': 0.2,
                'stroke': 'black',
                'stroke-width': 1
            };
        },
        getCurrentAttributes: function() {
            // use plus sign to convert string into number
            return {
                cx  : this.element.attr('cx'),
                cy	: this.element.attr('cy'),
                r  : this.element.attr('r')
            };
        },

        init: function(newX, newY) {
            let circleElement = selection.select('#selection_circle')
                .datum({x: newX, y: newY, r: 0})
                .attr('cx', 0)
                .attr('cy', 0)
                .attr('r', 0)
                .attr('fill-opacity', 0.2)
                .attr('stroke-width', 1)
                .classed("selectionCircle", true);
            this.setElement(circleElement);
            this.originX = newX;
            this.originY = newY;
            this.update(newX, newY);
        },
        update: function(newX, newY) {
            this.currentX = newX;
            this.currentY = newY;
            let newAttributes = this.getNewAttributes();
            this.element
                .attr('cx', newAttributes['cx'])
                .attr('cy', newAttributes['cy'])
                .attr('r', newAttributes['r']);
        },
        focus: function() {
            this.element
                .attr("stroke", "#DE695B")
                .attr("stroke-width", "2");
        },
        removeFocus: function() {
            this.element
                .attr("stroke", "None");
        }
    };
}
