let cur_t = {'x': 0, 'y': 0, 'k': 1};
let selected_circles = [];
let cur_papers_coords = [];
let show_contour = false;
let clicked_landmark_id = undefined;
let global_scale_x = undefined, global_scale_y = undefined;
const disabled_color = '#888', enabled_color = 'black';
const min_r = 20;
max_topic_p_th = 0.2
let type = 'topic';

topic_landmarks = [{'topic_id': 0, 'avg_x': 4.897, 'avg_y': 5.235}, {'topic_id': 1, 'avg_x': 6.732, 'avg_y': 10.316}, {'topic_id': 2, 'avg_x': 8.609, 'avg_y': 7.524}, {'topic_id': 3, 'avg_x': 10.715, 'avg_y': -1.986}, {'topic_id': 4, 'avg_x': 10.225, 'avg_y': 5.147}, {'topic_id': 5, 'avg_x': 17.365, 'avg_y': 7.912}, {'topic_id': 6, 'avg_x': 13.127, 'avg_y': 4.425}, {'topic_id': 7, 'avg_x': 9.414, 'avg_y': 2.416}, {'topic_id': 8, 'avg_x': 6.373, 'avg_y': 0.701}, {'topic_id': 9, 'avg_x': 11.155, 'avg_y': 8.891}]

const papers_map_svg = d3.select('#papers_map_div')
    .append('svg')
    .attr('id', 'papers_map_svg')
    .attr('width', col2_w)
    .attr('height', papers_map_div_height);

const papers_circles_g = papers_map_svg.append('g').attr('id', 'papers_circles_g');
const topic_landmarks_g = papers_map_svg.append('g').attr('id', 'topic_landmarks_g');
const galaxy_text_g = papers_map_svg.append('g').attr('id', 'galaxy_text_g');
const galaxy_more_g = papers_map_svg.append('g').attr('id', 'galaxy_more_g');
const galaxy_ratio_g = papers_map_svg.append('g').attr('id', 'galaxy_ratio_g');
const kde_g = papers_map_svg.append('g').attr('id', 'kde_g');
const legend_g = papers_map_svg.append('g').attr('id', 'legend_g');
const toolbox_g = papers_map_svg.append('g').attr('id', 'toolbox_g')
    .attr('transform', `translate(${col2_w - 22}, ${0})`);
const selectionCircle = CreateSelectionCircle(papers_map_svg);

const tooltip = d3.select('body')
    .append('div')
    .attr('id', 'tooltip')
    .attr('class', 'tooltip')
    .style('opacity', 1)
    .style('display', 'none');

toolbox_g.append('rect')
    .attr('x', -20)
    .attr('width', 40)
    .attr('height', 210)
    .attr('fill', 'white')
    .attr('fill-opacity', 0.8)
    .style('pointer-events', 'none');

kde_g
    .attr("fill", "none")
    .attr("stroke", "black")
    .attr("stroke-width", 0.5)
    .attr("stroke-linejoin", "round");

const galaxy_zoom = d3.zoom()
    .scaleExtent([1 / 2, 32])
    .on("zoom", function () {
        const t = d3.event.transform;
        const transform = `translate(${t.x}, ${t.y}) scale(${t.k})`;
        papers_circles_g.attr('transform', transform);
        topic_landmarks_g.attr('transform', transform);
        kde_g.attr('transform', transform);
        cur_t = t;
        tooltip.style('display', 'none')
    });

const selection_circle_drag = d3.drag()
    .on("start", dragStart_)
    .on("drag", dragMove_)
    .on("end", dragEnd_);

const selection_circle = papers_map_svg.append('circle')
    .attr('id', 'selection_circle')
    .call(selection_circle_drag);

function dragStart_() {
    galaxy_text_g.selectAll('*').remove();
    galaxy_more_g.selectAll('*').remove();
    galaxy_ratio_g.selectAll('*').remove();
    if (selected_circles && change_stroke) selected_circles.attr('stroke', 'none')
}

function dragMove_(d) {
    d3.select(this).attr('cx', d.x = d3.event.x).attr('cy', d.y = d3.event.y);
}

function dragEnd_(d) {
    const selected_ids = [];
    selected_circles = papers_circles_g.selectAll('circle').filter(function (p) {
        const x = p.x * cur_t.k + cur_t.x;
        const y = p.y * cur_t.k + cur_t.y;
        if (distance([x, y], [d.x, d.y]) <= d.r) {
            if (change_stroke && change_stroke) d3.select(this).attr('stroke', 'black');
            selected_ids.push(p.id);
            return true;
        } else {
            return false;
        }
    });

    if (selected_ids.length > 0) {
        const min_r = 20;
        $.post('/get_selected_papers_data', {
            r: Math.max(min_r * 1.5, d.r * 1.4),
            selected_ids: JSON.stringify(selected_ids),
            cur_min_year: cur_min_year,
            cur_max_year: cur_max_year
        }, function (data) {
            data = JSON.parse(data);
            console.log('Received data:', data);//
            const points = data['points'],
                h = data['h'],
                words = data['words'],
                journals = data['journals'],
                authors = data['authors'],
                topics = data['topics'].map(t => ({'topic': Topics[t['topic']].name, 'n': t['n']}));

            pie_update(journals, 'journal', d);
            if (type === 'topic') pie_update(topics, 'topic', d);
            else pie_update(journals, 'journal', d);
            words_update(points, words, d, h, 'left');
            words_update(points, authors, d, h, 'right');
        });
    }
}

const galaxy_drag = d3.drag()
    .on("start", drag_start)
    .on("drag", drag_move)
    .on("end", drag_end);

function drag_start() {
    tooltip.style('display', 'none');
    selection_circle.attr('display', 'inline').raise();
    selectionCircle.init(...d3.mouse(this));
    if (selected_circles && change_stroke) selected_circles.attr('stroke', 'none');

    galaxy_text_g.selectAll('*').remove();
    galaxy_more_g.selectAll('*').remove();
    galaxy_ratio_g.selectAll('*').remove();
}

function drag_move() {
    const selection_c = selectionCircle.getCurrentAttributes();
    selectionCircle.update(...d3.mouse(this));
    const r = selection_c.r;

    if (r > min_r) selectionCircle.focus();
    else selectionCircle.removeFocus();
}

function drag_end() {
    if (selectionCircle.getCurrentAttributes().r > min_r)
        selection_circle.attr('display', 'inline');
    else
        selection_circle.attr('display', 'none');
}

const bg_rect = papers_map_svg.append('rect')
    .attr('id', 'bg_rect')
    .attr("fill", "none")
    .attr('pointer-events', 'all')
    .attr("width", col2_w)
    .attr("height", papers_map_div_height)
    .on('click', function () {
        kde_g.selectAll('*').remove();
        contour_text.attr('fill', disabled_color);
        show_contour = false;
        tooltip.style('display', 'none');
        clicked_landmark_id = undefined;
        const [x, y] = d3.mouse(this);
    })
    .call(galaxy_zoom);

const legend_topic_text = legend_g.append('text')
    .style('pointer-events', 'all')
    .attr('alignment-baseline', 'hanging')
    .attr('text-anchor', 'start')
    .attr('dx', 10)
    .attr('dy', 10)
    .attr('font-weight', 'bold')
    .attr('font-size', '21px')
    .text('Topics')
    .on('click', function () {
        type = 'topic';
        update_legend(Topics, );
        legend_subject_text.attr('fill', 'grey').style('pointer-events', 'all');
        legend_topic_text.attr('fill', 'black').style('pointer-events', 'none');
        update_papers_plot();
    })

const legend_subject_text = legend_g.append('text')
    .style('pointer-events', 'all')
    .attr('alignment-baseline', 'hanging')
    .attr('text-anchor', 'start')
    .attr('dx', 80)
    .attr('dy', 10)
    .attr('font-weight', 'bold')
    .attr('font-size', '21px')
    .text('Journals')
    .attr('fill', 'grey')
    .on('click', function () {
        type = 'subject';
        update_legend(Subjects, );
        legend_topic_text.attr('fill', 'grey').style('pointer-events', 'all');
        legend_subject_text.attr('fill', 'black').style('pointer-events', 'none');
        update_papers_plot();
    });

update_legend(Topics, 'topic');

function update_legend(items) {
    legend_g.selectAll('.legend_item_g').remove();
    legend_g
        .selectAll('.legend_item_g')
        .data(items)
        .enter()
        .append('g')
        .attr('class', 'legend_item_g')
        .attr('transform', (d, i) => `translate(10, ${30 * i + 40})`)
        .each(function (d, i) {
            const g = d3.select(this);
            g.append('rect')
                .attr('width', 30)
                .attr('height', 25)
                .attr('rx', 3)
                .attr('ry', 3)
                .attr('dy', 15)
                .attr('fill', d.color)
                .on('mouseover', function () {
                    d3.select(this).attr('stroke', 'black').attr('stroke-width', 2);
                    const coords = type === 'subject' ? cur_papers_coords.filter(t => t['subject'] === d.name) :
                        cur_papers_coords.filter(t => t['topic_id'] === i);
                    update_contour(coords);
                })
                .on('mouseout', function () {
                    d3.select(this).attr('stroke', 'none');
                    kde_g.selectAll('*').remove();
                });
            g.append('text')
                .attr('alignment-baseline', 'middle')
                .attr('text-anchor', 'start')
                .attr('dx', 35)
                .attr('dy', 15)
                .attr('font-weight', 'bold')
                .attr('font-size', '20px')
                .text(d.name);
        });
}


const zoom_text = toolbox_g.append('text')
    .attr('id', 'zoom_text')
    .attr('class', 'fa')
    .attr('y', 20)
    .attr('text-anchor', 'middle')
    .attr('font-size', '25px')
    .style('pointer-events', 'all')
    .attr('alignment-baseline', 'central')
    .on('mousedown', function () {
        d3.event.stopPropagation();
    })
    .on('click', function () {
        bg_rect.on('.drag', null);
        bg_rect.call(galaxy_zoom);

        zoom_text.attr('fill', enabled_color);
        drag_text.attr('fill', disabled_color);

        bootoast.toast({
            message: `zoom ✔, drag ❌`,
            position: 'bottom-center',
            timeout: 2,
            type: 'info'
        });

        tooltip.style('display', 'none');
        selection_circle.attr('display', 'none');
        if (selected_circles && change_stroke) selected_circles.attr('stroke', 'none');

        galaxy_text_g.selectAll('*').remove();
        galaxy_more_g.selectAll('*').remove();
        galaxy_ratio_g.selectAll('*').remove();
    })
    .text('\uf00e');
zoom_text.append('title')
    .text('zoom and pan');

const drag_text = toolbox_g.append('text')
    .attr('id', 'drag_text')
    .attr('class', 'fa')
    .attr('y', 55)
    .attr('fill', disabled_color)
    .attr('text-anchor', 'middle')
    .attr('font-size', '25px')
    .style('pointer-events', 'all')
    .attr('alignment-baseline', 'central')
    .on('mousedown', function () {
        d3.event.stopPropagation();
    })
    .on('click', function () {
        bg_rect.on('.zoom', null);
        bg_rect.call(galaxy_drag);

        zoom_text.attr('fill', disabled_color);
        drag_text.attr('fill', enabled_color);

        bootoast.toast({
            message: `zoom ❌, drag ✔`,
            position: 'bottom-center',
            timeout: 2,
            type: 'info'
        });

        kde_g.selectAll('path').remove();
    })
    .text('\uf1ce');
drag_text.append('title')
    .text('circle selection');

const fit_text = toolbox_g.append('text')
    .attr('id', 'fit_text')
    .attr('class', 'fa')
    .attr('y', 90)
    .attr('text-anchor', 'middle')
    .attr('font-size', '25px')
    .attr('font-family', 'helvetica')
    .attr('alignment-baseline', 'central')
    .style('pointer-events', 'all')
    .on('mousedown', function () {
        d3.event.stopPropagation();
    })
    .on('click', function () {
        bg_rect.call(galaxy_zoom.transform, d3.zoomIdentity);
        tooltip.style('display', 'none');
        selection_circle.attr('display', 'none');
        if (selected_circles && change_stroke)
            selected_circles.attr('stroke', 'none');
        galaxy_text_g.selectAll('*').remove();
        galaxy_more_g.selectAll('*').remove();
        galaxy_ratio_g.selectAll('*').remove();
        cur_t = {'x': 0, 'y': 0, 'k': 1};
    })
    .text('\uf31e');
fit_text.append('title')
    .text('fit to center');

const contour_text = toolbox_g.append('text')
    .attr('id', 'contour_text')
    .attr('class', 'fa')
    .attr('y', 125)
    .attr('alignment-baseline', 'central')
    .style('pointer-events', 'all')
    .attr('text-anchor', 'middle')
    .attr('font-size', '25px')
    .attr('fill', disabled_color)
    .on('mousedown', function () {
        d3.event.stopPropagation();
    })
    .on('click', function () {
        tooltip.style('display', 'none');
        if (!show_contour) {
            update_contour(cur_papers_coords);
            contour_text.attr('fill', enabled_color);
            legend_g.selectAll('rect').style('pointer-events', 'none');
        } else {
            contour_text.attr('fill', disabled_color);
            kde_g.selectAll('*').remove();
            legend_g.selectAll('rect').style('pointer-events', 'all');
        }
        show_contour = !show_contour;
    })
    .text('\uf5d2');
contour_text.append('title')
    .text("show contour");

function show_histogram() {
    const svg = d3.select('#time_filter_svg');
    const nums = d3.range(global_max_year - global_min_year + 1).map(d => 0);
    for (const p of init_papers_list) {
        if (p.year >= global_min_year && p.year <= global_max_year)
            nums[p.year - global_min_year] += 1
    }
    const bin_width = col2_w / nums.length;
    const height_scale = d3.scaleLinear()
        .domain([0, d3.max(nums)])
        .range([0, time_filter_div_height - 5]);
    svg.append('g')
        .attr('id', 'histogram_g')
        .selectAll('rect')
        .data(nums)
        .enter()
        .append('rect')
        .attr('x', (d, i) => i * bin_width)
        .attr('y', d => time_filter_div_height - height_scale(d))
        .attr('width', bin_width)
        .attr('height', d => height_scale(d) - 1)
        .attr('fill', '#aaa')
        .attr('stroke', '#555')
        .on('mouseover', function () {
            d3.select(this)
                .attr('stroke', 'black')
                .attr('stroke-width', 2)
                .raise();
        })
        .on('mouseout', function () {
            d3.select(this)
                .attr('stroke', '#555')
                .attr('stroke-width', 1);
        })
        .append('title')
        .text(d => d);
    svg.select('#brush_g').raise();
}

function show_landmarks() {
    const topic_landmarks = papers_data['topic_landmarks'];
    topic_landmarks.forEach(function (d) {
        d.x = global_scale_x(d['avg_x']);
        d.y = global_scale_y(d['avg_y']);
    });

    const topic_texts = topic_landmarks_g
        .selectAll('text')
        .data(topic_landmarks);

    topic_texts
        .enter()
        .append('text')
        .attr("text-anchor", "middle")
        .attr('alignment-baseline', 'central')
        .attr('font-size', 16 + 'px')
        .attr('font-family', 'helvetica')
        .attr('x', d => d['x'])
        .attr('y', d => d['y'])
        .attr('fill', 'black')
        .text(d => Topics[d['topic_id']].name)
        .each(function (d) {
            d['width'] = d3.select(this).node().getComputedTextLength() + 4;
        });

    topic_landmarks_g
        .selectAll('.landmark_rect')
        .data(topic_landmarks)
        .enter()
        .append('rect')
        .attr('id', (r, i) => 'topic_' + i)
        .attr('class', 'landmark_rect')
        .attr('width', d => d['width'])
        .attr('height', 22)
        .attr('x', d => d['x'] - d['width'] / 2)
        .attr('y', d => d['y'] - 11)
        .attr('fill', 'white')
        .attr('fill-opacity', 0.7)
        .attr('stroke', '#aaa')
        .attr('stroke-width', 2)
        .on('mousedown', function () {
            d3.event.stopPropagation();
        })
        .on('mouseover', function (d) {
            d3.select(this).attr('stroke', '#555');
            const selected_circles = papers_circles_g.selectAll('circle').filter(t => t['topic_id'] === d['topic_id']);
            selected_circles.attr('stroke', 'black');
        })
        .on('mouseout', function (d, i) {
            d3.select(this).attr('stroke', '#aaa');
            papers_circles_g.selectAll('circle').filter(t => t['topic_id'] === d['topic_id']).attr('stroke', 'none');
        })
        .on('click', show_landmark_tooltip);
}

function show_landmark_tooltip(d) {
    if (d.topic_id === clicked_landmark_id) {
        tooltip.style('display', 'none');
        clicked_landmark_id = undefined;
    } else {
        clicked_landmark_id = d.topic_id;
        $.post('/get_topic_data', {'topic_id': d.topic_id}, function (topic_data) {
            topic_data = JSON.parse(topic_data);
            const tooltip_w = 250;
            const tooltip_h = 250;
            const evolution_g_h = 50;
            const wordcloud_h = 200;

            const word_probability = topic_data['word_probability'];
            const size_scale = d3.scaleLinear()
                .domain(d3.extent(word_probability.map(x => x[1])))
                .rangeRound([15, 22]);
            const words = word_probability.map(x =>
                ({'text': x[0], 'size': size_scale(x[1])}));

            tooltip
                .style('display', 'inline')
                .style('left', ((d['x'] + d['width'] / 2) * cur_t.k + cur_t.x + 20 + 10) + 'px')
                .style('top', (d['y'] * cur_t.k + cur_t.y - tooltip_h / 2 + time_filter_div_height) + 'px')
                .selectAll('*')
                .remove();
            const tooltip_svg = tooltip.append('div')
                .append('svg')
                .attr('width', tooltip_w)
                .attr('height', tooltip_h);
            const evolution_g = tooltip_svg.append('g');

            d3.layout.cloud()
                .size([tooltip_w, wordcloud_h])
                .words(words)
                .rotate(0)
                .padding(1)
                .fontSize(d => d.size)
                .on("end", draw_wordcloud)
                .start();

            function draw_wordcloud(words) {
                const wordcloud_g = tooltip_svg.append('g')
                    .attr('transform', `translate(${tooltip_w / 2}, ${evolution_g_h + wordcloud_h / 2})`);
                const topic_color = Topics[d.topic_id].color;
                wordcloud_g.append('rect')
                    .attr('width', tooltip_w)
                    .attr('height', wordcloud_h)
                    .attr('fill', topic_color)
                    .attr('fill-opacity', 0.5)
                    .attr('stroke', '#555')
                    .attr('transform', `translate(${-tooltip_w / 2}, ${-wordcloud_h / 2})`);
                wordcloud_g
                    .selectAll("text").data(words)
                    .enter().append("text")
                    .attr("font-size", d => d.size)
                    .attr("font-family", "Impact")
                    .attr("text-anchor", "middle")
                    .attr('alignment-baseline', 'middle')
                    .attr('fill', 'black')
                    .attr('x', d => d.x)
                    .attr('y', d => d.y)
                    .text(d => d.text);
            }

            let year_distribution = topic_data['year_distribution'];
            const height_scale = d3.scaleLinear()
                .domain([0, d3.max(year_distribution)])
                .rangeRound([0, evolution_g_h - 5]);

            const year_num = global_max_year - global_min_year + 1;
            year_distribution = year_distribution.map((papers_num, year) => ({
                'year': year + global_min_year, 'papers_num': papers_num,
                'height': height_scale(papers_num), 'x': year / year_num * tooltip_w
            }));

            evolution_g
                .selectAll('rect')
                .data(year_distribution)
                .enter()
                .append('rect')
                .attr('width', tooltip_w / year_num)
                .attr('height', d => d.height)
                .attr('x', d => d.x)
                .attr('y', d => evolution_g_h - d.height)
                .attr('fill', '#69b3a2')
                .attr('stroke', '#cccccc')
                .attr('stroke-width', 1)
                .append('title')
                .text(d => d.year + ' #' + d.papers_num);
        });
    }
}

function update_papers_plot() {
    if (global_scale_x === undefined) {
        global_scale_x = d3.scaleLinear()
            .domain(d3.extent(papers_data['papers_list'], d => d.x))
            .range([padding, col2_w - padding]);
        global_scale_y = d3.scaleLinear()
            .domain(d3.extent(papers_data['papers_list'], d => d.y))
            .range([padding, papers_map_div_height - padding]);
        show_histogram();
    }

    // 获取主题0的中心坐标
    const topic0_center = topic_landmarks.find(d => d.topic_id === 0);
    const topic0_avg_x = topic0_center.avg_x;
    const topic0_avg_y = topic0_center.avg_y;
    cur_papers_coords = papers_data['papers_list']
        .filter(d => d['year'] >= cur_min_year && d['year'] <= cur_max_year)
        .map(d => {
            if (d.topic_id === 0) {
                const distance_x = d.x - topic0_avg_x;
                const distance_y = d.y - topic0_avg_y;
                const distance = Math.sqrt(distance_x * distance_x + distance_y * distance_y);
                const decay_factor = Math.max(0.1, 1 - distance / 100);
                if (d.x < 0.5) {
                    d.x = topic0_avg_x + distance_x * decay_factor*0.001;
                }
            }

            return {
                'id': d.id,
                'x': global_scale_x(d.x),
                'y': global_scale_y(d.y),
                'color': d.max_topic_p < max_topic_p_th ? '#ddd' : (type === 'subject' ? Subjects[d['subject_id']].color : Topics[d['topic_id']].color),
                'topic_id': d.topic_id,
                'subject': d.subject,
                'max_topic_p': d.max_topic_p
            };
        });

    console.log('point num:', cur_papers_coords.length);

    const papers_circles = papers_circles_g
        .selectAll('circle')
        .data(cur_papers_coords)
        .join(
            enter => enter.append('circle')
                .attr('fill', d => d.color)
                .attr('cx', d => d.x)
                .attr('cy', d => d.y)
                .attr('r', 3),
            update => update.attr('fill', d => d.color)
                .attr('cx', d => d.x)
                .attr('cy', d => d.y),
            exit => exit.remove()
        );

    topic_landmarks_g.raise();
    topic_landmarks_g.selectAll('text').raise();
    legend_g.raise();
    toolbox_g.raise();

    bootoast.toast({
        message: `Successfully loaded <b>${cur_papers_coords.length}</b> papers`,
        position: 'bottom-center',
        timeout: 3,
        type: 'info'
    });

    if (!show_contour) {
        kde_g.selectAll('*').remove();
        contour_text.attr('fill', disabled_color);
        show_contour = false;
    } else {
        update_contour(cur_papers_coords);
    }
}


function update_contour(coords) {
    const kde_g = d3.select('#kde_g');
    kde_g.selectAll('*').remove();

    const color = d3.scaleSequential(d3.interpolateYlGnBu).domain([0, 0.10]);
    kde_g.selectAll('path').remove();
    kde_g.selectAll("path")
        .data(d3.contourDensity()
            .x(d => d.x)
            .y(d => d.y)
            .size([col2_w, papers_map_div_height])
            .bandwidth(18)
            (coords))
        .enter().append("path")
        .on('mouseover', function () {
            d3.select(this).attr('stroke-width', 1);
        })
        .on('mouseout', function () {
            d3.select(this).attr('stroke-width', 0.5);
        })
        .attr('fill-opacity', 0.3)
        .attr("fill", d => color(d.value))
        .attr("d", d3.geoPath());
}
