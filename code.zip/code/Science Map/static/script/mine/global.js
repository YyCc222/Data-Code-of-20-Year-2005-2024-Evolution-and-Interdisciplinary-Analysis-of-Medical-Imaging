const col2_w = 1300;
const time_filter_div_height = 60,
    papers_map_div_height = 900;
const padding = 80;

const global_min_year = 2005,
    global_max_year = 2024;

let cur_min_year = global_min_year,
    cur_max_year = global_max_year;

const change_stroke = false;

const Topics = [
    {name: 'CDDG', color: '#4d78a6'},
    {name: 'BDNI', color: '#f08d2c'},
    {name: 'MIRG', color: '#df5658'},
    {name: 'CVHI', color: '#75b6b1'},
    {name: 'MIRC', color: '#58a04e'},
    {name: 'SNCP', color: '#ebc748'},
    {name: 'MISG', color: '#ae79a0'},
];

const Subjects = [
    {name: 'TMI', color: '#55b1f1'},
    {name: 'MIA', color: '#ef6a5e'},
    {name: 'MICCAI', color: '#6fec6f'}
];

let papers_data = undefined;
let init_papers_list = undefined;

$.post('/get_papers_data', {}, function (raw_data) {
    papers_data = JSON.parse(raw_data);
    init_papers_list = JSON.parse(JSON.stringify(papers_data['papers_list']));
    update_papers_plot('topic');
});
