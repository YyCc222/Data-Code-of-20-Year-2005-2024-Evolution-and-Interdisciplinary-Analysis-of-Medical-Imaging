function words_update(points, words, d, h, side) {
    words = words.map(w => ({'x': 0, 'y': 0, 'width': 0, 'text': w}));
    const text_g = d3.select('#galaxy_text_g').raise();
    let top_words = words.slice(0, points.length);
    let word_texts = text_g.selectAll('.' + side + 'text').data(top_words);
    word_texts.enter().append('text')
        .attr('class', side + 'text')
        .attr('text-anchor', side === 'left' ? 'end' : 'start')
        .attr('dy', '-.35em')
        .attr('font-size', h * 0.9 + 'px')
        .attr('font-family', 'helvetica')
        .attr('opacity', 0)
        .merge(word_texts)
        .attr('x', side === 'left' ? d.x - d.r : d.x + d.r)
        .attr('y', (p, i) => d.y - (p.y = (points[i][1] - h)))
        .text(p => p.text)
        .each(function (p) {
            p.width = d3.select(this).node().getComputedTextLength();
        })
        .transition()
        .duration(300)
        .attr('x', (p, i) => side === 'left' ? d.x - (p.x = points[i][0]): d.x + (p.x = points[i][0]))
        .attr('opacity', 1);
    word_texts.exit().remove();

    let word_rects = text_g.selectAll('.' + side + 'rect').data(top_words);
    word_rects.enter().append('rect')
        .attr('class', side + 'rect')
        .attr('height', h)
        .attr('fill', 'white')
        .attr('fill-opacity', 0.9)
        .merge(word_rects)
        .attr('id', (p, i) => 'a' + i)
        .attr('text', p => p.text)
        .attr('width', p => p.width)
        .attr('x', (p, i) => side === 'left' ? d.x - points[i][0] - p.width : d.x + points[i][0])
        .attr('y', (p, i) => d.y - points[i][1] - 2)
        .on('mousedown', function () {
            d3.event.stopPropagation();
        })
        .on('mouseover', function () {
            d3.select(this).attr('fill', '#aaa');
        })
        .on('mouseout', function () {
            d3.select(this).attr('fill', 'white');
        });
    word_rects.exit().remove();
    text_g.selectAll('text').raise();
}


let outerRadius, innerRadius = 0;
let cur_circles;

function pie_update(data, type, d) {
    const pie = d3.pie().value(d => d.n).startAngle(-Math.PI / 2).endAngle(3 * Math.PI / 2);
    if (type === 'journal') innerRadius = d.r + 2;
    else innerRadius = outerRadius + 2;

    outerRadius = innerRadius + Math.max(5, d.r / 10);
    const arc = d3.arc().innerRadius(innerRadius).outerRadius(outerRadius);

    const ratio_g = d3.select('#galaxy_ratio_g').raise();
    const ratio_path = ratio_g.selectAll('.' + type).data(pie(data));
    ratio_path.enter().append('path')
        .attr('class', type)
        .attr('opacity', 0)
        .attr('stroke', 'black')
        .merge(ratio_path)
        .attr("fill", type === 'journal' ? '#e31a1c' : '#33a02c')
        .attr('fill-opacity', 0.7)
        .on('mouseover', function (p) {
            d3.select(this).attr('stroke-width', 2);
            cur_circles = selected_circles
                .filter(function (c) {
                    return c[type + '_id'] === p.data[type];
                })
                .attr('fill', type === 'journal' ? 'red' : 'green')
                .raise();
        })
        .on('mouseout', function () {
            d3.select(this).attr('stroke-width', 1);
            cur_circles.attr('fill', d => d.color).lower();
        })
        .attr('d', arc)
        .attr('transform', `translate(${d.x}, ${d.y})`)
        .transition()
        .duration(300)
        .attr('opacity', 1);
    ratio_path.exit().remove();

    ratio_g.selectAll('.' + type)
        .each(function (p) {
            let text = p['data'][type] + ' ' + p['data']['n'];
            const title = d3.select(this).select('title');
            if (title.empty()) d3.select(this).append('title').text(p['data'][type] + ' ' + p['data']['n']);
            else title.text(text);
        })
}
