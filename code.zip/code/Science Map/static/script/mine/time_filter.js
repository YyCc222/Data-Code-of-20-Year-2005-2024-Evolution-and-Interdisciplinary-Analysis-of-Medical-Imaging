function draw_papers_time_filter() {
    const filter_g_h = time_filter_div_height;
    const time_filter_svg = d3.select('#time_filter_div')
        .append('svg')
        .attr('id', 'time_filter_svg')
        .attr('width', col2_w)
        .attr('height', time_filter_div_height);

    const ticks_num = Math.floor((global_max_year - global_min_year) / 5);
    const year_scale = d3.scaleLinear()
        .domain([global_min_year, global_max_year + 1])
        .rangeRound([0, col2_w]);

    time_filter_svg.append("g")
        .attr("class", "axis axis--grid")
        .attr("transform", "translate(0," + filter_g_h + ")")
        .call(d3.axisBottom(year_scale)
            .ticks(ticks_num)
            .tickSize(-filter_g_h));

    time_filter_svg.append("g")
        .attr("class", "axis axis--x")
        .call(d3.axisBottom(year_scale)
            .ticks(ticks_num)
            .tickPadding(0)
        .tickFormat(d => d))
        .attr("text-anchor", 'start')
        .selectAll("text")
        .attr("x", 6);

    const papers_num_bar_g = time_filter_svg.append('g');

    const min_date_text = time_filter_svg.append('text')
        .attr('y', filter_g_h / 2 + 10)
        .attr('dx', -5)
        .attr("text-anchor", "end")
        .attr('font-size', 15 + 'px')
        .attr('font-family', 'helvetica');

    const max_date_text = time_filter_svg.append('text')
        .attr('y', filter_g_h / 2 + 10)
        .attr('dx', 5)
        .attr("text-anchor", "start")
        .attr('font-size', 15 + 'px')
        .attr('font-family', 'helvetica');

    const brush = d3.brushX()
        .extent([[0, 0], [col2_w, filter_g_h]])
        .on("start", brush_start)
        .on("brush", brushing)
        .on("end", brush_end);

    const brush_g = time_filter_svg.append("g")
        .attr('id', 'brush_g')
        .call(brush)
        .call(brush.move, [0, col2_w]);

    let cur_selection = [0, col2_w];

    function brush_start() {
        if (!d3.event.sourceEvent) return;
        if (!d3.event.selection) return;
        papers_num_bar_g.selectAll('*').remove();
    }

    function brush_end() {
        if (!d3.event.sourceEvent) return;
        if (!d3.event.selection) {
            brush_g.call(brush.move, cur_selection);
            return;
        }
        const d0 = d3.event.selection.map(year_scale.invert),
            d1 = d0.map(Math.round);
        if (d1[0] === d1[1]) {
            d1[0] = Math.floor(d0[0]);
            d1[1] = d1[0] + 1;
        }
        if (cur_min_year === d1[0] && cur_max_year === d1[1] - 1) return;

        cur_min_year = d1[0];
        cur_max_year = d1[1] - 1;
        cur_selection = [d1[0], d1[1]].map(year_scale);
        d3.select(this).transition().call(d3.event.target.move, d1.map(year_scale));
        update_papers_plot();
        papers_circles_g.attr('filter', 'none');
    }

    function brushing() {
        const d0 = d3.event.selection.map(year_scale.invert),
            d1 = d0.map(Math.round);
        if (d1[0] === d1[1]) {
            d1[0] = Math.floor(d0[0]);
            d1[1] = d1[0] + 1;
        }
        min_date_text.attr('x', Math.max(d3.event.selection[0], 5))
            .text(d1[0]);
        max_date_text.attr('x', Math.min(d3.event.selection[1], col2_w - 5))
            .text(d1[1] - 1);
    }
}

draw_papers_time_filter();

