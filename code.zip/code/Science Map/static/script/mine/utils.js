function str(int) {
    return int.toString();
}

function int(str) {
    return parseInt(str);
}

function num2date(num) {
    let date = new Date(global_min_date);
    date.setDate(date.getDate() + num);
    return date;
}

function distance([x1, y1], [x2, y2]) {
    return Math.sqrt((x1-x2)**2+(y1-y2)**2);
}

function reverse(input) {
    let ret = [];
    for(let i = input.length-1; i >= 0; i--) {
        ret.push(input[i]);
    }
    return ret;
}

function wrap(text, width, x) {
    let words = text.text().split('').reverse(),
        word,
        line = [],
        lineNumber = 0,
        lineHeight = 1.1,
        y = text.attr("y"),
        dy = parseFloat(text.attr("dy")),
        tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");
    while (word = words.pop()) {
      line.push(word);
      tspan.text(line.join(" "));
      if (tspan.node().getComputedTextLength() > width) {
        line.pop();
        tspan.text(line.join(" "));
        line = [word];
        tspan = text.append("tspan")
            .attr("x", x)
            .attr("y", y)
            .attr("dy", ++lineNumber * lineHeight + dy + "em")
            .text(word);
      }
    }

}

function closestPoint(pathNode, point) {
    let pathLength = pathNode.getTotalLength(),
      precision = 8,
      best,
      bestLength,
      bestDistance = Infinity;

    for (let scan, scanLength = 0, scanDistance; scanLength <= pathLength; scanLength += precision) {
        if ((scanDistance = distance2(scan = pathNode.getPointAtLength(scanLength))) < bestDistance) {
          best = scan, bestLength = scanLength, bestDistance = scanDistance;
        }
    }

    precision /= 2;
    while (precision > 0.5) {
    let before,
        after,
        beforeLength,
        afterLength,
        beforeDistance,
        afterDistance;
    if ((beforeLength = bestLength - precision) >= 0 && (beforeDistance = distance2(before = pathNode.getPointAtLength(beforeLength))) < bestDistance) {
          best = before, bestLength = beforeLength, bestDistance = beforeDistance;
        } else if ((afterLength = bestLength + precision) <= pathLength && (afterDistance = distance2(after = pathNode.getPointAtLength(afterLength))) < bestDistance) {
          best = after, bestLength = afterLength, bestDistance = afterDistance;
        } else {
          precision /= 2;
        }
    }

    best = [best.x, best.y];
    best.distance = Math.sqrt(bestDistance);
    return best;

    function distance2(p) {
        let dx = p.x - point[0],
            dy = p.y - point[1];
        return dx * dx + dy * dy;
    }
}

function yOnPath(path, target_xs, h) {
    const target_ys = [];
    let length = 0, id = 0;
    const totalLength = path.getTotalLength();
    const step = Math.max(totalLength/2000, 4);
    let {x, y} = path.getPointAtLength(0);
    while(length <= totalLength) {
        if(target_xs[id] <= x) {
            target_ys.push(Math.max(h - y, 0));
            id += 1;
        } else {
            length += step;
            ({x, y} = path.getPointAtLength(length));
            continue
        }
        if(id === target_xs.length) break;
    }
    return target_ys;
}


function findY(path, x, h) {
    let pathLength = path.getTotalLength();
    let start = 0;
    let end = pathLength;
    let target = (start + end) / 2;
    let th = 1;
    while (target >= start && target <= pathLength) {
        let pos = path.getPointAtLength(target);
        // use a threshold instead of strict equality
        // to handle javascript floating point precision
        if (Math.abs(pos.x - x) < th) return h - pos.y;
        else if (pos.x > x) end = target - th;
        else start = target + th;
        target = (start + end) / 2
  }
}