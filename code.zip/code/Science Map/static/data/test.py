from collections import defaultdict
import json

with open('papers.json', 'r', encoding='utf-8') as f:
    papers = json.load(f)
topic_word_freq = defaultdict(lambda: defaultdict(int))
topic_year_distribution = defaultdict(lambda: defaultdict(int))
for paper in papers:
    topic_id = paper['topic_id']
    year = paper.get('publication_year', None)
    content = paper['cleaned_content'].strip()
    if not content:
        continue
    words = content.split(' ')
    for word in words:
        topic_word_freq[topic_id][word] += 1
    if year is not None:
        topic_year_distribution[topic_id][year] += 1

word_probability_list = []
for topic_id in sorted(topic_word_freq.keys()):
    word_freqs = topic_word_freq[topic_id]
    total_count = sum(word_freqs.values())
    word_probabilities = [
        [word, round(10000 * count / total_count, 4)]
        for word, count in word_freqs.items()
    ]
    word_probabilities.sort(key=lambda x: x[1], reverse=True)
    word_probability_list.append({"word_probability": word_probabilities})

with open('word_probability1.json', 'w', encoding='utf-8') as f:
    json.dump(word_probability_list, f, ensure_ascii=False, indent=2)

results = []
for topic_id in sorted(topic_word_freq.keys()):
    word_probability = word_probability_list[topic_id]['word_probability']
    yearly_dist = topic_year_distribution[topic_id]
    year_distribution = [yearly_dist.get(year, 0) for year in range(2005, 2025)]

    results.append({
        'word_probability': word_probability,
        'year_distribution': year_distribution
    })
with open('topic_descriptors.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)