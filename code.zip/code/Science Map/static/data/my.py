import json
import numpy as np
import umap
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from transformers import AutoTokenizer
from adapters import AutoAdapterModel

papers_json_file_path = 'papers.json'
papers_txt_file_path = 'papers.txt'

# specter2
with open(papers_txt_file_path, 'r', encoding='utf-8') as f:
    papers_txt = [line.strip() for line in f.readlines()]

tokenizer = AutoTokenizer.from_pretrained('allenai/specter2_base')
model = AutoAdapterModel.from_pretrained('allenai/specter2_base')
embeddings = []
for paper in papers_txt:
    inputs = tokenizer(paper, return_tensors="pt", padding=True, truncation=True, max_length=51)
    outputs = model(**inputs)
    cls_embeddings = outputs.last_hidden_state[:, 0, :].detach().numpy()
    embeddings.append(cls_embeddings)

# PCA
pca = PCA(n_components=10)
coordinate = pca.fit_transform(embeddings)

# umap
umap_model=umap.UMAP(
                  n_components=2,
                  metric='cosine',
                  verbose=True)
coordinates = umap_model.fit_transform(coordinate)

with open(papers_txt_file_path, 'r', encoding='utf-8') as f:
    papers_txt = f.readlines()
print(len(papers_txt))
with open(papers_json_file_path, 'r',encoding='utf-8') as f:
    papers = json.load(f)
for i, paper in enumerate(papers):
    print(i)
    if i < min(len(papers), len(papers_txt)):
        paper['x'] = round(float(coordinates[i, 0]), 8)
        paper['y'] = round(float(coordinates[i, 1]), 8)
    else:
        print(paper)
with open(papers_json_file_path, 'w',encoding='utf-8') as f:
    json.dump(papers, f)

with open(papers_json_file_path, 'r',encoding='utf-8') as f:
    papers = json.load(f)
plt.figure(figsize=(10, 8))
plt.scatter([paper['x'] for paper in papers], [paper['y'] for paper in papers])
plt.title('UMAP Visualization of Paper Vectors')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()

# coord
with open(papers_json_file_path, 'r', encoding='utf-8') as f:
    papers = json.load(f)
paper_vectors = np.array([[paper['x'], paper['y']] for paper in papers if 'x' in paper and 'y' in paper])
with open('paper_topic.txt', 'r', encoding='utf-8') as file:
    lines = file.readlines()
topic_prob_matrix = np.zeros((len(lines), 10))
for i, line in enumerate(lines):
    topic, prob = line.strip().split()
    topic_index = int(topic)
    topic_prob_matrix[i, topic_index] = float(prob)
num_topics = 10
topic_vectors = np.zeros((num_topics, 2))
for topic in range(num_topics):
    topic_paper_indices = np.where(topic_prob_matrix[:, topic] > 0)[0]
    sum_vector = np.sum(paper_vectors[topic_paper_indices] * topic_prob_matrix[topic_paper_indices, topic][:, np.newaxis], axis=0)
    prob_sum = np.sum(topic_prob_matrix[:, topic])
    if prob_sum > 0:
        topic_vectors[topic] = sum_vector / prob_sum
print(len(topic_vectors))
with open('pre_coord.txt', 'w', encoding='utf-8') as f:
    for topic_vector in topic_vectors:
        f.write(f"{topic_vector[0]} {topic_vector[1]}\n")