from flask import Flask, render_template, request, redirect, url_for, jsonify
import os
import json
from collections import defaultdict, Counter
import random
from utils import *

app = Flask(__name__)

topic_num = 7
data_path = r'static\data'
global_min_year = 2005
global_max_year = 2024
papers = []
topic_dict = {
    0:'CDDG', 1:'BDNI', 2:'MIRG', 3:'CVHI', 4:'MIRC', 5:'SNCP', 6:'MISG'
}
with open(os.path.join(data_path, 'papers.json'), encoding='utf-8') as f:
    all_papers = json.load(f)
with open(os.path.join(data_path, 'topic_descriptors.json'), encoding='utf-8') as f:
    all_topics = json.load(f)

topic_landmarks = [{'topic_id': 0, 'avg_x': 4.897, 'avg_y': 5.235}, {'topic_id': 1, 'avg_x': 6.732, 'avg_y': 10.316}, {'topic_id': 2, 'avg_x': 8.609, 'avg_y': 7.524}, {'topic_id': 3, 'avg_x': 10.715, 'avg_y': -1.986}, {'topic_id': 4, 'avg_x': 10.225, 'avg_y': 5.147}, {'topic_id': 5, 'avg_x': 17.365, 'avg_y': 7.912}, {'topic_id': 6, 'avg_x': 13.127, 'avg_y': 4.425}, {'topic_id': 7, 'avg_x': 9.414, 'avg_y': 2.416}, {'topic_id': 8, 'avg_x': 6.373, 'avg_y': 0.701}, {'topic_id': 9, 'avg_x': 11.155, 'avg_y': 8.891}]

@app.route('/')
def hello_world():
    return redirect(url_for('index'))


@app.route('/index')
def index():
    return render_template('index.html')


@app.route('/get_papers_data', methods=['POST'])
def get_papers_data():
    papers_list=all_papers
    return json.dumps({'papers_list': papers_list, 'topic_landmarks': topic_landmarks})


@app.route('/get_selected_papers_data', methods=['POST'])
def get_selected_papers_data():
    r = float(request.form['r'])
    cur_min_year = int(request.form['cur_min_year'])
    cur_max_year = int(request.form['cur_max_year'])
    selected_ids = set(json.loads(request.form['selected_ids']))
    top_n = 10
    h, points = find_fine_h(r=r)
    indexes = set()
    all_indexes = set()

    journals = defaultdict(int)
    authors = defaultdict(int)
    subjects = defaultdict(int)
    topics = defaultdict(int)

    for index_, paper in enumerate(all_papers):
        if paper['year'] and cur_min_year <= paper['year'] <= cur_max_year:
            all_indexes.add(index_)
            if paper['id'] in selected_ids:
                indexes.add(index_)
                journals[paper['journal']] += 1
                subjects[paper['subject']] += 1
                topics[paper['topic_id']] += 1
                for author in paper['author'].split(';'):
                    authors[author] += 1

    journals = [{'journal': x[0], 'n': x[1]} for x in Counter(journals).most_common(top_n) if x[0] != '']
    authors = [x[0] + ' ' + str(x[1]) for x in Counter(authors).most_common(top_n) if x[0] != '']
    subjects = [{'subject': x[0], 'n': x[1]} for x in Counter(subjects).most_common(top_n) if x[0] != '']
    topics = [{'topic': x[0], 'n': x[1]} for x in Counter(topics).most_common(top_n)]
    print(topics)
    corpus1 = []
    corpus2 = []
    if not len(papers):
        with open(os.path.join(data_path, 'papers.txt'), encoding='utf-8') as f:
            for line in f:
                papers.append(line)
    for index_, line in enumerate(papers):
        line = line.strip()
        if index_ in indexes:
            corpus1.append(line)
        elif index_ in all_indexes:
            corpus2.append(line)
    target_corpus = random.choices(corpus1, k=300)
    corpus = target_corpus + random.choices(corpus2, k=300)

    corpus_counter = Counter(' '.join(corpus).split(' '))
    target_counter = Counter(' '.join(target_corpus).split(' '))
    word2g2 = g2_statistics(corpus_counter, target_counter)
    words = typesetting(word2g2, len(points) + 10, max_length=25)
    words = [w for w in words if '-' in w]

    return json.dumps(
        {'words': words, 'journals': journals, 'authors': authors, 'topics': topics, 'subjects': subjects,
         'points': points, 'h': h})


@app.route('/get_topic_data', methods=['POST'])
def get_topic_data():
    topic_id = int(request.form['topic_id'])
    return json.dumps(all_topics[topic_id])

@app.route('/get_topic_landmarks')
def get_topic_landmarks():
    return jsonify(topic_landmarks)


if __name__ == '__main__':
    app.run(debug=True)
