const width = 1400;
const height = 1400;
const topicMap = {
  0: 'CDDG',
  1: 'BDNI',
  2: 'MIRG',
  3: 'CVHI',
  4: 'MIRC',
  5: 'SNCP',
  6: 'MISG'
};
const svg = d3.select("svg")
  .attr("width", width)
  .attr("height", height);
const g = svg.append("g")
  .attr("transform", "translate(150, 0)");
Promise.all([
  d3.json("data/nodes.json"),
  d3.json("data/edges.json")
]).then(function([nodesData, linksData]) {
  const color = d3.scaleOrdinal()
  .domain([0, 1, 2, 3, 4, 5, 6])
  .range(['#4d78a6','#f08d2c','#df5658', '#75b6b1', '#58a04e', '#ebc748','#ae79a0']);
  const minYear = d3.min(nodesData, d => d.publication_year);
  const maxYear = d3.max(nodesData, d => d.publication_year);
  const yearRange = maxYear - minYear;
  const topics = [...new Set(nodesData.map(d => d.topic_id))];
  const minCitations = d3.min(nodesData, d => d.cited_by_count);
  const maxCitations = d3.max(nodesData, d => d.cited_by_count);
  const radiusScale = d3.scaleSqrt()
    .domain([minCitations, maxCitations])
    .range([6, 13])
    .clamp(true);
  const years = [...new Set(nodesData.map(d => d.publication_year))].sort(d3.ascending);
  const yearDividers = years.map(year => ({
    year: year,
    y: 100 + ((year - minYear) / yearRange) * (height - 200)
  }));
  const topicCenters = {};
  const topicWidth = (width - 80) / topics.length * 0.6;
  topics.forEach((topic, i) => {
    topicCenters[topic] = {
      x: 80 + (i + 0.5) * topicWidth,
      y: height / 2
    };
  });
  nodesData.forEach(d => {
    d.r = radiusScale(d.cited_by_count);
    const baseY = 100 + ((d.publication_year - minYear) / yearRange) * (height - 200);
    d.y = baseY + (Math.random() - 0.5) * 30;
    d.targetY = d.y;
    const center = topicCenters[d.topic_id];
    const randomSpread = topicWidth * 0.2;
    d.x = center.x + (Math.random() - 0.5) * randomSpread;
    d.targetX = d.x;
  });

  const yearLinesGroup = svg.append("g")
    .attr("class", "year-lines-group");

  const specialYears = [2012.5, 2019.5];
  const specialYearLines = yearLinesGroup.selectAll(".special-year-line")
  .data(specialYears)
  .enter().append("line")
  .attr("class", "special-year-line")
  .attr("x1", 0)
  .attr("x2", width - 100)
  .attr("y1", d => 100 + ((d - minYear) / yearRange) * (height - 200))
  .attr("y2", d => 100 + ((d - minYear) / yearRange) * (height - 200))
  .attr("stroke", "#494949")
  .attr("stroke-width", 2)
  .attr('opacity',0.7)
  .attr("stroke-dasharray", "10,5");
  const legendGroup = svg.append("g") 
    .attr("class", "legend-group")
    .attr("transform", `translate(${width - 300}, 100) scale(1.3)`);
  const yearLabelsGroup = svg.append("g")
    .attr("class", "year-labels-group");
  const linkGroup = g.append("g")
    .attr("class", "link-group");
  const nodeGroup = g.append("g")
    .attr("class", "node-group");
  const legendBackground = legendGroup.append("rect")
    .attr("x", -10)
    .attr("y", -10)
    .attr("width", 180)
    .attr("height", topics.length * 25 + 40)
    .attr("fill", "white")
    .attr("stroke", "#ddd")
    .attr("stroke-width", 1)
    .attr("rx", 5)
    .attr("ry", 5)
    .style("filter", "drop-shadow(0px 2px 4px rgba(0,0,0,0.1))");
  yearLinesGroup.selectAll(".year-divider")
    .data(yearDividers)
    .enter().append("line")
    .attr("class", "year-divider")
    .attr("x1", 50)
    .attr("x2", width - 100) 
    .attr("y1", d => d.y)
    .attr("y2", d => d.y)
    .attr("stroke", "#ddd")
    .attr("stroke-width", 1)
    .attr("stroke-dasharray", "5,5");
  yearLabelsGroup.selectAll(".year-label")
    .data(years)
    .enter().append("text")
    .attr("class", "year-label")
    .attr("x", 50)
    .attr("y", d => 100 + ((d - minYear) / yearRange) * (height - 200))
    .attr("dy", "0.35em")
    .attr("text-anchor", "end")
    .attr("font-size", "20px")
    .attr("font-weight", "bold")
    .attr("fill", "#666")
    .text(d => d);
  yearLinesGroup.lower();
  const simulation = d3.forceSimulation(nodesData)
    .force("link", d3.forceLink(linksData)
      .id(d => d.id)
      .distance(d => {
        const timeDiff = Math.abs(d.source.publication_year - d.target.publication_year);
        return 50 + timeDiff * 20;
      })
      .strength(0)
    )
    .force("collide", d3.forceCollide()
      .radius(d => d.r + 1)
      .strength(0.8)
    )
    .force("cluster", clusterForce)
    .force("y", d3.forceY(d => d.targetY)
      .strength(5.0)
    )
    .force("x", d3.forceX(d => d.targetX)
      .strength(0.05)
    )
    .alphaDecay(0.01)
    .velocityDecay(0.3)
    .on("tick", ticked);
  function clusterForce(alpha) {
    const currentTopicCenters = {};
    topics.forEach(topic => {
      const topicNodes = nodesData.filter(d => d.topic_id === topic);
      currentTopicCenters[topic] = {
        x: d3.mean(topicNodes, d => d.x),
        y: d3.mean(topicNodes, d => d.y)
      };
    });
    for (let i = 0; i < nodesData.length; ++i) {
      const node = nodesData[i];
      const center = currentTopicCenters[node.topic_id];
      node.vx += (center.x - node.x) * alpha * 1.0;
      node.vy += (center.y - node.y) * alpha * 0.2;
      for (let j = i + 1; j < nodesData.length; ++j) {
        const other = nodesData[j];
        if (node.topic_id !== other.topic_id) {
          const dx = node.x - other.x;
          const dy = node.y - other.y;
          const l = Math.sqrt(dx * dx + dy * dy);
          if (l > 0 && l < 150) {
            const k = alpha * 50 / l;
            node.vx += dx * k;
            node.vy += dy * k * 0.2;
            other.vx -= dx * k;
            other.vy -= dy * k * 0.2;
          }
        }
      }
    }
  }
  const link = linkGroup.selectAll(".link")
    .data(linksData)
    .enter().append("path")
    .attr("class", "link")
    .attr("fill", "none")
    .attr("stroke", "#999")
    .attr("stroke-opacity", 0.6)
    .attr("stroke-width", 1.5);
  const nodes = nodeGroup.selectAll(".node")
    .data(nodesData)
    .enter().append("g")
    .attr("class", "node")
    .call(d3.drag()
      .on("start", dragstarted)
      .on("drag", dragged)
      .on("end", dragended));
  nodes.append("circle")
    .attr("r", d => d.r)
    .attr("fill", d => color(d.topic_id))
    .attr("stroke", "#fff")
    .attr("stroke-width", 2);
  const tooltip = d3.select("body").append("div")
    .attr("class", "tooltip")
    .style("position", "absolute")
    .style("visibility", "hidden")
    .style("background-color", "white")
    .style("border", "1px solid #ddd")
    .style("border-radius", "4px")
    .style("padding", "10px")
    .style("max-width", "300px")
    .style("word-wrap", "break-word");
  nodes.on("mouseover", function(event, d) {
    handleMouseOver(event, d);
    tooltip.html(`
      <strong>Title:</strong> ${d.title}<br/>
      <strong>Year:</strong> ${d.publication_year}<br/>
      <strong>Topic:</strong> ${d.topic_id}<br/>
      <strong>Citations:</strong> ${d.cited_by_count}<br/>
      <strong>Authors:</strong> ${d.authors ? d.authors.join(", ") : "Unknown"}
    `)
    .style("visibility", "visible")
    .style("top", (event.pageY - 10) + "px")
    .style("left", (event.pageX + 10) + "px");
  })
  .on("mousemove", function(event) {
    tooltip.style("top", (event.pageY - 10) + "px")
           .style("left", (event.pageX + 10) + "px");
  })
  .on("mouseout", function(event, d) {
    handleMouseOut(event, d);
    tooltip.style("visibility", "hidden");
  });
  function ticked() {
    link.attr("d", function(d) {
      const sourceX = d.source.x;
      const sourceY = d.source.y;
      const targetX = d.target.x;
      const targetY = d.target.y;
      const dx = targetX - sourceX;
      const dy = targetY - sourceY;
      const dr = Math.sqrt(dx * dx + dy * dy);
      const offset = Math.min(50, dr * 0.2);
      if (sourceY < targetY) {
        return `M${sourceX},${sourceY}C${sourceX},${sourceY + offset} ${targetX},${targetY - offset} ${targetX},${targetY}`;
      } else {
        return `M${sourceX},${sourceY}C${sourceX},${sourceY - offset} ${targetX},${targetY + offset} ${targetX},${targetY}`;
      }
    });
    nodes.attr("transform", d => `translate(${d.x},${d.y})`);
  }
  function dragstarted(event, d) {
    if (!event.active) simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
  }
  function dragged(event, d) {
    d.fx = event.x;
    d.fy = d.y;
  }
  function dragended(event, d) {
    if (!event.active) simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
  }
  function handleMouseOver(event, d) {
    const relatedLinks = linksData.filter(link => 
      link.source.id === d.id || link.target.id === d.id
    );
    const relatedNodeIds = new Set();
    relatedLinks.forEach(link => {
      relatedNodeIds.add(link.source.id);
      relatedNodeIds.add(link.target.id);
    });
    link
      .attr("stroke", linkData => 
        (linkData.source.id === d.id || linkData.target.id === d.id) ? "black" : "#999"
      )
      .attr("stroke-width", linkData => 
        (linkData.source.id === d.id || linkData.target.id === d.id) ? 3 : 1.5
      )
      .attr("stroke-opacity", linkData => 
        (linkData.source.id === d.id || linkData.target.id === d.id) ? 1 : 0.3
      );
    nodes
      .select("circle")
      .attr("stroke", nodeData => 
        relatedNodeIds.has(nodeData.id) ? "black" : "#fff"
      )
      .attr("stroke-width", nodeData => 
        relatedNodeIds.has(nodeData.id) ? 3 : 2
      )
      .attr("opacity", nodeData => 
        relatedNodeIds.has(nodeData.id) ? 1 : 0.7
      );
    link.filter(linkData => 
      linkData.source.id === d.id || linkData.target.id === d.id
    ).raise();
    nodes.filter(nodeData => 
      relatedNodeIds.has(nodeData.id)
    ).raise();
  }
  function handleMouseOut(event, d) {
    link
      .attr("stroke", "#999")
      .attr("stroke-width", 1.5)
      .attr("stroke-opacity", 0.6);
    nodes
      .select("circle")
      .attr("stroke", "#fff")
      .attr("stroke-width", 2)
      .attr("opacity", 1);
  }
  const sortedTopics = topics.sort((a, b) => d3.ascending(a, b));
  const legendItems = legendGroup.selectAll(".legend-item")
    .data(sortedTopics)
    .enter().append("g")
    .attr("class", "legend-item")
    .attr("transform", (d, i) => `translate(0, ${i * 25})`);
  legendItems.append("rect")
    .attr("width", 18)
    .attr("height", 18)
    .attr("fill", d => color(d));
  legendItems.append("text")
    .attr("x", 24)
    .attr("y", 9)
    .attr("dy", "0.35em")
    .attr("font-size", "16px")
    .text(d => topicMap[d]);
  legendGroup.append("text")
    .attr("x", 0)
    .attr("y", topics.length * 25 + 20)
    .attr("text-anchor", "start")
    .attr("font-size", "13px")
    .attr("fill", "#666")
    .text(`Total number of nodes: ${nodesData.length}`);
}).catch(function(error) {
  console.log(error);
});