var svg = d3.select("#sankey-chart")
    .attr("width", 1000)
    .attr("height", 600);

const format = d3.format("$.3s");

const color = d3.scaleOrdinal(d3.schemeSet3);
const Topics = [
    {name: 'CDDG', color: '#4d78a6'},
    {name: 'BDNI', color: '#f08d2c'},
    {name: 'MIRG', color: '#df5658'},
    {name: 'CVHI', color: '#75b6b1'},
    {name: 'MIRC', color: '#58a04e'},
    {name: 'SNCP', color: '#ebc748'},
    {name: 'MISG', color: '#ae79a0'},
];
// 建立 name -> color 映射表
const topicColorMap = {};
Topics.forEach(t => {
    topicColorMap[t.name] = t.color;
});
// 准备左侧节点颜色池（避开左侧颜色）
const allColors = d3.schemeSet3; // 可以根据需要替换更多颜色
const rightColors = Object.values(topicColorMap);
const leftColorsPool = allColors.filter(c => !rightColors.includes(c));
let leftColorIndex = 0;
// 给右侧节点生成颜色映射
const leftColorMap = {};
function getLeftColor(name) {
    if (!leftColorMap[name]) {
        leftColorMap[name] = leftColorsPool[leftColorIndex % leftColorsPool.length];
        leftColorIndex++;
    }
    return leftColorMap[name];
}
function createSankeyChart(data) {
  const width = window.innerWidth * 0.8;
  const height = window.innerHeight * 0.6;

  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, height])
      .attr("width", width)
      .attr("height", height);

  const nameOrder = ['CDDG', 'BDNI', 'MIRG', 'CVHI', 'MIRC', 'SNCP', 'MISG'];
  const sankeyGenerator = d3.sankey()
      //.nodeSort((a, b) => a.id - b.id)
      .nodeSort((a, b) => {
          const ia = nameOrder.indexOf(a.name);
          const ib = nameOrder.indexOf(b.name);
          if (ia !== -1 && ib !== -1) return ia - ib;
          if (ia === -1 && ib === -1) return b.value - a.value;
          return (ia === -1) - (ib === -1);
      })
      .nodeId(d => d.id)
      .linkSort(null)
      .nodeWidth(15)
      .nodePadding(10)
      .extent([[1, 5], [width - 1, height - 5]]);

  const { nodes: sankeyNodes, links: sankeyLinks } = sankeyGenerator({ nodes: data.nodes, links: data.links });

  const leftNodesG = svg.append("g")
    .attr("class", "left_g")
    .selectAll("g")
    .data(sankeyNodes.filter(d => d.x0 === 1))
    .join("g");
  leftNodesG.append("rect")
    .attr("stroke", "#000")
    .attr("x", d => d.x0)
    .attr("y", d => d.y0)
    .attr("height", d => d.y1 - d.y0)
    .attr("width", d => d.x1 - d.x0)
    .attr("fill", d => color(d.name) || getRightColor(d.name));
  leftNodesG.append("title")
    .text(d => `${d.name}: ${d.value}`);
  leftNodesG.append("text")
    .attr("x", d => d.x1 + 6)
    .attr("y", d => (d.y1 + d.y0) / 2)
    .attr("dy", "0.35em")
    .attr("text-anchor", "start")
    .style("font", "14px sans-serif")
    .text(d => `${d.name}: ${d.value}`);

  const rightNodesG = svg.append("g")
    .attr("class", "right_g")
    .selectAll("g")
    .data(sankeyNodes
        .filter(d => d.x0 > 1)
        .sort((a, b) => b.value - a.value)
    )
    .join("g");
  rightNodesG.append("rect")
    .attr("stroke", "#000")
    .attr("x", d => d.x0)
    .attr("y", d => d.y0)
    .attr("height", d => d.y1 - d.y0)
    .attr("width", d => d.x1 - d.x0)
    .attr("fill", d => topicColorMap[d.name]);
  rightNodesG.append("title")
    .text(d => `${d.name}: ${d.value}`);
  rightNodesG.append("text")
    .attr("x", d => d.x0 - 10)             // 放在节点左侧
    .attr("y", d => (d.y1 + d.y0) / 2)
    .attr("dy", "0.35em")
    .attr("text-anchor", "end")
    .style("font", "15px sans-serif")
    .text(d => `${d.name}: ${d.value}`);


  // 定义渐变
  const gradient = svg.append("defs")
    .selectAll("linearGradient")
    .data(sankeyLinks)
    .enter().append("linearGradient")
    .attr("id", (d, i) => `grad-${i}`)
    .attr("gradientUnits", "userSpaceOnUse")
    .attr("x1", (d)=>d.source.x1)
    .attr("x2", (d)=>d.target.x0)
    .attr("y1", (d)=>d.source.y0+(d.source.y1-d.source.y0)/2)
    .attr("y2", (d)=>d.target.y0+(d.target.y1-d.target.y0)/2);

  gradient.append("stop")
    .attr("offset", "0%")
    .attr("stop-color", d => color(d.source.name));
    //.attr("stop-color", d => topicColorMap[d.source.name] || "#9b8686");

  gradient.append("stop")
    .attr("offset", "100%")
    //.attr("stop-color", d => color(d.target.name));
    .attr("stop-color", d => topicColorMap[d.target.name] || "#9b8686");


  svg.append("g")
      .attr("fill", "none")
      .attr("stroke-opacity", 0.8)
    .selectAll("path")
    .data(sankeyLinks)
    .join("path")
      .attr("d", d3.sankeyLinkHorizontal())
      //.attr("stroke", d => color(d.source.name))
      .attr("stroke", d => `url(#grad-${sankeyLinks.indexOf(d)})`)
      .attr("stroke-opacity", 0.6)
      .attr("stroke-width", d => Math.max(1, d.width))
      .append("title")
      //.text(d => `${d.source.name} → ${d.target.name}\n${format(d.value)}`);
      .text(d => `${d.source.name} → ${d.target.name}\n${d.value}`);


  svg.select(".left_g").raise();
  svg.select(".right_g").raise();

  document.body.appendChild(svg.node());

  window.addEventListener('resize', function() {
    document.body.innerHTML = '';
    createSankeyChart(data);
  });
}

createSankeyChart(data);
