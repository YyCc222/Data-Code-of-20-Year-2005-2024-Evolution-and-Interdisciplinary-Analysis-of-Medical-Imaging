const costType = 'tco';
async function loadData() {
    let links = [];
    const csvData = await d3.csv("data/CS_right.txt", d3.autoType);
    
    csvData.sort((a, b) => a['NAME_1'] - b['NAME_1']);
    
    csvData.map((row, i) => {
        if (costType === row['TYPE_EXPENSE'] || costType === 'tco') {
            links.push({
                source: row['NAME_1'],
                target: row['NAME_2'],
                value: row['VALUE'],
                id: i,
            });

            links.push({
                source: row['NAME_2'],
                target: row['EXPENSE'],
                type: row['TYPE_EXPENSE'],
                value: row['VALUE_2'],
                id: i,
            });
        }
    });

    const nodes = Array.from(new Set(links.flatMap(l => [l.source, l.target])), (name, id) => ({ name, id }));
    
    links.map(d => {
        d.source = nodes.find(e => e.name === d.source).id;
        d.target = nodes.find(e => e.name === d.target).id;
    });

    const sankeyData = { nodes, links };
    createSankeyChart(sankeyData);
}

loadData();
